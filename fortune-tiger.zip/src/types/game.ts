export type SymbolType = "🐯" | "🪙" | "💎" | "🎰" | "🔔" | "🍀" | "7️⃣" | "🎲";

export interface SpinOutcome {
  win: boolean;
  label: string;
  amount: number;
}

export interface CommentItem {
  name: string;
  time: string;
  text: string;
  color: string;
  photo?: string;
  author?: boolean;
}

export type SlotGameState = "idle" | "spinning" | "win" | "mega-win" | "lose";
