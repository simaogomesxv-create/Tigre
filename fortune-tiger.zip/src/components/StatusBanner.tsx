import { AnimatePresence, motion } from "motion/react";
import { SlotGameState } from "../types/game";

interface StatusBannerProps {
  state: SlotGameState;
}

export const StatusBanner = ({ state }: StatusBannerProps) => {
  return (
    <div className="h-14 flex items-center justify-center my-1 relative overflow-visible">
      <AnimatePresence mode="wait">
        {state === "spinning" && (
          <motion.div
            key="spinning"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.0, repeat: Infinity, ease: "easeInOut" }}
            className="text-sm font-bold tracking-[0.25em]"
            style={{ color: "#DAA520", fontFamily: "'Russo One', sans-serif" }}
          >
            A GIRAR...
          </motion.div>
        )}

        {state === "win" && (
          <motion.div
            key="win"
            className="relative flex items-center justify-center"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.85, opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Soft radiant ambient circle */}
            <motion.div
              className="absolute rounded-full pointer-events-none"
              style={{
                width: 140,
                height: 140,
                background: "radial-gradient(circle, hsla(45, 100%, 50%, 0.3) 0%, transparent 70%)",
              }}
              animate={{ scale: [1, 1.4, 1.2], opacity: [0.3, 0.7, 0.4] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            />

            {[...Array(8)].map((_, i) => {
              const angle = (i / 8) * Math.PI * 2;
              const isGold = i % 2 === 0;
              return (
                <motion.div
                  key={i}
                  className="absolute rounded-full pointer-events-none"
                  style={{
                    width: 4,
                    height: 4,
                    background: isGold ? "#FFD700" : "#FFA500",
                    boxShadow: `0 0 6px ${isGold ? "#FFD700" : "#FFA500"}`,
                  }}
                  initial={{ x: 0, y: 0, opacity: 0 }}
                  animate={{
                    x: Math.cos(angle) * (50 + (i % 3) * 15),
                    y: Math.sin(angle) * (30 + (i % 2) * 15),
                    opacity: [0, 0.9, 0],
                    scale: [0.5, 1.2, 0],
                  }}
                  transition={{ duration: 1.2, delay: i * 0.08, repeat: Infinity, ease: "easeOut" }}
                />
              );
            })}

            <motion.div
              className="text-xl font-bold relative z-10 select-none tracking-wide"
              style={{
                background: "linear-gradient(180deg, #FFE57F, #FFB300)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                fontFamily: "'Russo One', sans-serif",
                filter: "drop-shadow(0 0 12px rgba(255, 215, 0, 0.7))",
              }}
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            >
              ✨ GANHOU! ✨
            </motion.div>
          </motion.div>
        )}

        {state === "mega-win" && (
          <motion.div
            key="mega"
            className="relative flex items-center justify-center"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.85, opacity: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Soft warm aura */}
            <motion.div
              className="absolute rounded-full pointer-events-none"
              style={{
                width: 180,
                height: 180,
                background:
                  "radial-gradient(circle, hsla(35, 100%, 55%, 0.35) 0%, hsla(45, 100%, 50%, 0.15) 50%, transparent 70%)",
              }}
              animate={{ scale: [1, 1.35, 1.15], opacity: [0.5, 0.9, 0.6] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            />

            {[...Array(12)].map((_, i) => {
              const angle = (i / 12) * Math.PI * 2;
              const radius = 55 + (i % 4) * 12;
              const color = i % 3 === 0 ? "#FF6B35" : i % 3 === 1 ? "#FFD700" : "#FFF8DC";
              return (
                <motion.div
                  key={i}
                  className="absolute rounded-full pointer-events-none"
                  style={{
                    width: 3.5,
                    height: 3.5,
                    background: color,
                    boxShadow: `0 0 6px ${color}`,
                  }}
                  initial={{ x: 0, y: 0, opacity: 0 }}
                  animate={{
                    x: Math.cos(angle) * radius,
                    y: Math.sin(angle) * radius * 0.7,
                    opacity: [0, 0.9, 0],
                    scale: [0.5, 1.3, 0],
                  }}
                  transition={{
                    duration: 1.4,
                    delay: i * 0.06,
                    repeat: Infinity,
                    ease: "easeOut",
                  }}
                />
              );
            })}

            <motion.div
              className="text-2xl font-bold relative z-10 select-none tracking-wide"
              style={{
                background: "linear-gradient(180deg, #FFF3C4, #FFB300, #FF6F00)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                fontFamily: "'Russo One', sans-serif",
                filter: "drop-shadow(0 0 16px rgba(255, 165, 0, 0.8)) drop-shadow(0 0 30px rgba(255, 215, 0, 0.4))",
              }}
              animate={{ scale: [1, 1.06, 1] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            >
              🔥 MEGA GANHO! 🔥
            </motion.div>
          </motion.div>
        )}

        {state === "lose" && (
          <motion.div
            key="lose"
            className="relative flex items-center justify-center"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <motion.div
              className="absolute rounded-full pointer-events-none"
              style={{
                width: 120,
                height: 120,
                background: "radial-gradient(circle, rgba(239, 68, 68, 0.25) 0%, transparent 70%)",
              }}
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.2, 0] }}
              transition={{ duration: 0.6 }}
            />
            <div
              className="text-lg font-bold relative z-10 select-none tracking-wider text-rose-400"
              style={{
                fontFamily: "'Russo One', sans-serif",
                filter: "drop-shadow(0 0 8px rgba(244, 63, 94, 0.5))",
              }}
            >
              ❌ TENTE DE NOVO ❌
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
