import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { SymbolType } from "../types/game";
import { SYMBOLS } from "../utils/constants";
import { SparkleParticle } from "./ParticleBurst";

interface ReelColumnProps {
  symbols: SymbolType[];
  spinning: boolean;
  delay: number;
  winRow: number | null;
}

export const ReelColumn = ({ symbols, spinning, delay, winRow }: ReelColumnProps) => {
  const [displaySymbols, setDisplaySymbols] = useState<SymbolType[]>(symbols);
  const [isSpinningLocal, setIsSpinningLocal] = useState(false);
  const [justSettled, setJustSettled] = useState(false);

  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null;
    let startTimeout: NodeJS.Timeout | null = null;
    let stopTimeout: NodeJS.Timeout | null = null;

    if (spinning) {
      setJustSettled(false);
      startTimeout = setTimeout(() => {
        setIsSpinningLocal(true);
        intervalId = setInterval(() => {
          setDisplaySymbols([
            SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
            SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
            SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          ]);
        }, 55);
      }, delay * 250);

      return () => {
        if (startTimeout) clearTimeout(startTimeout);
        if (intervalId) clearInterval(intervalId);
      };
    } else {
      // Staggered smooth stop
      stopTimeout = setTimeout(() => {
        if (intervalId) clearInterval(intervalId);
        setIsSpinningLocal(false);
        setDisplaySymbols(symbols);
        setJustSettled(true);
        setTimeout(() => setJustSettled(false), 400);
      }, delay * 500);

      return () => {
        if (stopTimeout) clearTimeout(stopTimeout);
      };
    }
  }, [spinning, symbols, delay]);

  // When symbols change while idle, update immediately
  useEffect(() => {
    if (!spinning && !isSpinningLocal) {
      setDisplaySymbols(symbols);
    }
  }, [symbols, spinning, isSpinningLocal]);

  return (
    <div className="flex-1 flex flex-col h-[270px] overflow-hidden relative border-r last:border-r-0 border-amber-500/25 bg-[#140303] select-none">
      {displaySymbols.map((sym, rowIdx) => {
        const isWinner = !isSpinningLocal && winRow === rowIdx;

        return (
          <motion.div
            key={`row-${rowIdx}`}
            className="w-full h-[90px] flex items-center justify-center relative border-b last:border-b-0 border-amber-500/20"
            style={{
              background: isWinner
                ? "linear-gradient(180deg, #421010 0%, #260505 100%)"
                : rowIdx % 2 === 0
                ? "linear-gradient(180deg, #240808 0%, #160404 100%)"
                : "linear-gradient(180deg, #1c0606 0%, #100202 100%)",
            }}
            animate={
              isSpinningLocal
                ? {
                    y: [0, -12, 0],
                    filter: "blur(1.4px)",
                    opacity: [0.85, 1, 0.85],
                  }
                : justSettled
                ? {
                    y: [-6, 2, 0],
                    scale: [1.06, 0.98, 1],
                    filter: "blur(0px)",
                    opacity: 1,
                  }
                : isWinner
                ? {
                    scale: [1, 1.08, 1],
                    filter: "blur(0px)",
                    opacity: 1,
                  }
                : {
                    y: 0,
                    scale: 1,
                    filter: "blur(0px)",
                    opacity: 1,
                  }
            }
            transition={
              isSpinningLocal
                ? {
                    duration: 0.12,
                    repeat: Infinity,
                    ease: "linear",
                  }
                : justSettled
                ? {
                    duration: 0.35,
                    ease: "easeOut",
                  }
                : isWinner
                ? {
                    duration: 1.1,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }
                : {
                    duration: 0.2,
                  }
            }
          >
            {/* Winning Glowing Halo */}
            {isWinner && (
              <>
                <motion.div
                  className="absolute inset-[3px] rounded-lg pointer-events-none z-10"
                  style={{
                    background: "radial-gradient(circle, hsla(45, 100%, 55%, 0.22) 0%, transparent 75%)",
                    border: "2px solid hsla(45, 100%, 55%, 0.75)",
                  }}
                  animate={{
                    boxShadow: [
                      "0 0 10px hsla(45, 100%, 50%, 0.4), inset 0 0 8px hsla(45, 100%, 50%, 0.25)",
                      "0 0 25px hsla(45, 100%, 50%, 0.75), inset 0 0 16px hsla(45, 100%, 50%, 0.4)",
                      "0 0 10px hsla(45, 100%, 50%, 0.4), inset 0 0 8px hsla(45, 100%, 50%, 0.25)",
                    ],
                  }}
                  transition={{ duration: 1.1, repeat: Infinity, ease: "easeInOut" }}
                />
                {[...Array(6)].map((_, i) => (
                  <SparkleParticle key={i} index={i} />
                ))}
              </>
            )}

            {/* Inner Golden Corner Accents for Filled Slot Aesthetics */}
            <div className="absolute top-1 left-1 w-1.5 h-1.5 border-t border-l border-amber-500/20 pointer-events-none" />
            <div className="absolute top-1 right-1 w-1.5 h-1.5 border-t border-r border-amber-500/20 pointer-events-none" />
            <div className="absolute bottom-1 left-1 w-1.5 h-1.5 border-b border-l border-amber-500/20 pointer-events-none" />
            <div className="absolute bottom-1 right-1 w-1.5 h-1.5 border-b border-r border-amber-500/20 pointer-events-none" />

            {/* Main Symbol Emoji */}
            <span
              className="relative z-10 text-[52px] leading-none select-none drop-shadow-md transition-transform"
              style={{
                filter: isWinner
                  ? "drop-shadow(0 0 14px rgba(255, 215, 0, 0.85))"
                  : "drop-shadow(0 2px 4px rgba(0,0,0,0.6))",
              }}
            >
              {sym}
            </span>
          </motion.div>
        );
      })}

      {/* Top & Bottom Depth Vignettes */}
      <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-b from-black/60 to-transparent pointer-events-none z-20" />
      <div className="absolute bottom-0 left-0 right-0 h-3 bg-gradient-to-t from-black/60 to-transparent pointer-events-none z-20" />
    </div>
  );
};
