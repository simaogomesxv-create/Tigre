import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { createAudioEngine } from "../utils/audio";
import {
  EXPRESS_LOGO,
  formatKz,
  MULTICAIXA_LOGO,
  TEMPLE_BG,
} from "../utils/constants";
import { LiveStreamView } from "./LiveStreamView";

interface WithdrawModalProps {
  totalWin: number;
}

type MethodType = "none" | "express" | "iban";
type StepType = "choose" | "form" | "processing" | "confirmed" | "activation";

export const WithdrawModal = ({ totalWin }: WithdrawModalProps) => {
  const [method, setMethod] = useState<MethodType>("none");
  const [step, setStep] = useState<StepType>("choose");
  const [expressPhone, setExpressPhone] = useState("");
  const [fullName, setFullName] = useState("");
  const [ibanPhone, setIbanPhone] = useState("");
  const [ibanNumber, setIbanNumber] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const audio = createAudioEngine();

  const formatPhone = (val: string) => {
    const raw = val.replace(/\D/g, "").slice(0, 9);
    if (raw.length <= 3) return raw;
    if (raw.length <= 6) return `${raw.slice(0, 3)} ${raw.slice(3)}`;
    return `${raw.slice(0, 3)} ${raw.slice(3, 6)} ${raw.slice(6)}`;
  };

  const formatIban = (val: string) => {
    const clean = val.replace(/\s/g, "").toUpperCase();
    if (clean.length <= 4) return clean;
    let base = clean;
    if (!base.startsWith("AO")) {
      base = "AO06" + base.replace(/^AO\d{0,2}/, "");
    }
    const digits = base.slice(4).replace(/\D/g, "").slice(0, 21);
    const combined = base.slice(0, 4) + digits;
    const chunks = combined.match(/.{1,4}/g);
    return chunks ? chunks.join(" ") : combined;
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (method === "express") {
      const clean = expressPhone.replace(/\D/g, "");
      if (clean.length !== 9 || !clean.startsWith("9")) {
        errs.express = "Número deve começar com 9 e ter 9 dígitos";
      }
    } else {
      if (!fullName.trim() || fullName.trim().length < 2) {
        errs.fullName = "Insira o nome completo";
      }
      const cleanPhone = ibanPhone.replace(/\D/g, "");
      if (cleanPhone.length !== 9 || !cleanPhone.startsWith("9")) {
        errs.phone = "Número deve começar com 9 e ter 9 dígitos";
      }
      const cleanIban = ibanNumber.replace(/\s/g, "");
      if (cleanIban.length !== 25 || !cleanIban.startsWith("AO06")) {
        errs.iban = "IBAN deve ter formato AO06 + 21 dígitos";
      }
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  useEffect(() => {
    if (step === "processing") {
      const timer = setTimeout(() => {
        setStep("confirmed");
        audio.playSuccess();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const bgStyle = {
    backgroundImage: `url(${TEMPLE_BG})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };

  if (step === "activation") {
    return <LiveStreamView totalWin={totalWin} />;
  }

  if (step === "processing") {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-[#0d0d12]">
        <motion.div
          className="text-center px-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <motion.div
            className="w-16 h-16 rounded-full mx-auto mb-6 border-3 border-white/10 border-t-white/70"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
          <h2
            className="text-xl font-bold text-white mb-2"
            style={{ fontFamily: "'Russo One', sans-serif" }}
          >
            Verificando seus dados
          </h2>
          <p className="text-sm mb-6 text-[#666]">Por favor aguarde...</p>
          <div className="w-64 h-1 rounded-full mx-auto overflow-hidden bg-white/10">
            <motion.div
              className="h-full rounded-full bg-white/40"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 3, ease: "linear" }}
            />
          </div>
        </motion.div>
      </div>
    );
  }

  if (step === "confirmed") {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto py-4"
        style={bgStyle}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
        <motion.div
          className="relative z-10 w-[calc(100%-40px)] max-w-[380px] mx-auto rounded-2xl p-6 text-center"
          style={{
            background: "linear-gradient(180deg, rgba(20,25,35,0.95), rgba(15,18,25,0.97))",
            border: "1px solid rgba(100,120,140,0.2)",
            boxShadow: "0 8px 40px rgba(0,0,0,0.5)",
          }}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3"
            style={{ background: "rgba(34,197,94,0.15)" }}
          >
            <span className="text-2xl">✅</span>
          </div>

          <h2
            className="text-lg font-bold mb-1 text-[#22c55e]"
            style={{ fontFamily: "'Russo One', sans-serif" }}
          >
            Dados verificados com sucesso
          </h2>
          <p className="text-xs mb-4 text-[#888]">Os seus dados foram validados</p>

          <div
            className="h-px mb-3"
            style={{
              background: "linear-gradient(90deg, transparent, rgba(100,100,120,0.3), transparent)",
            }}
          />

          <p className="text-xs mb-1 text-[#999]">Total disponível para levantamento</p>
          <motion.p
            className="text-3xl font-bold mb-4"
            style={{
              background: "linear-gradient(180deg, #22c55e, #16a34a)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              fontFamily: "'Orbitron', sans-serif",
            }}
            animate={{ scale: [1, 1.03, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {formatKz(totalWin)} Kz
          </motion.p>

          <div
            className="h-px mb-4"
            style={{
              background: "linear-gradient(90deg, transparent, rgba(100,100,120,0.3), transparent)",
            }}
          />

          <div className="text-left space-y-2.5 mb-5 text-[#ccc] text-xs">
            {method === "express" ? (
              <div className="flex items-center gap-2">
                <span>📱</span>
                <span>
                  Express: <strong className="text-white">{expressPhone}</strong>
                </span>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <span>👤</span>
                  <span className="text-white font-medium">{fullName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>📞</span>
                  <span>{ibanPhone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>🏦</span>
                  <span>
                    IBAN: <strong className="text-white">{ibanNumber}</strong>
                  </span>
                </div>
              </>
            )}
          </div>

          <motion.button
            onClick={() => setStep("activation")}
            className="w-full py-3.5 rounded-xl text-base font-bold cursor-pointer"
            style={{
              background: "linear-gradient(135deg, #FFD700, #DAA520, #FF8C00)",
              color: "#1a0505",
              fontFamily: "'Russo One', sans-serif",
            }}
            whileTap={{ scale: 0.97 }}
          >
            💰 Levantar meus ganhos agora
          </motion.button>
        </motion.div>
      </div>
    );
  }

  if (method === "none" || step === "choose") {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto py-4"
        style={bgStyle}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
        <motion.div
          className="relative z-10 w-[calc(100%-40px)] max-w-[380px] mx-auto rounded-2xl px-6 py-8"
          style={{
            background: "linear-gradient(180deg, rgba(20,25,35,0.95), rgba(15,18,25,0.97))",
            border: "1px solid rgba(100,120,140,0.2)",
            boxShadow: "0 8px 40px rgba(0,0,0,0.5)",
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h2
            className="text-xl font-bold text-white text-center mb-1"
            style={{ fontFamily: "'Russo One', sans-serif" }}
          >
            Levantamento
          </h2>
          <p className="text-xs text-center mb-3 text-[#888]">
            Escolha o meio de recebimento
          </p>

          <div
            className="rounded-xl px-4 py-4 mb-5 text-center"
            style={{
              background: "rgba(34,197,94,0.08)",
              border: "1px solid rgba(34,197,94,0.25)",
            }}
          >
            <p className="text-[10px] uppercase tracking-widest mb-1 text-[#999]">
              disponível para levantamento
            </p>
            <motion.p
              className="text-3xl font-bold"
              style={{
                background: "linear-gradient(180deg, #22c55e, #16a34a)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                fontFamily: "'Orbitron', sans-serif",
                filter: "drop-shadow(0 0 10px rgba(34,197,94,0.4))",
              }}
              animate={{ scale: [1, 1.04, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              {formatKz(totalWin)} Kz
            </motion.p>
          </div>

          <motion.button
            onClick={() => {
              setMethod("express");
              setStep("form");
              audio.playButtonClick();
            }}
            className="w-full rounded-xl p-4 mb-3 text-left flex items-center gap-3 cursor-pointer transition-colors"
            style={{
              background: "rgba(25,25,35,0.9)",
              border: "1px solid rgba(100,100,120,0.25)",
            }}
            whileTap={{ scale: 0.98 }}
          >
            <img
              src={EXPRESS_LOGO}
              alt="Express"
              className="w-10 h-10 rounded-lg object-contain bg-white/5 p-1"
            />
            <div>
              <p className="font-bold text-white text-sm">
                Registrar Multicaixa Express
              </p>
              <p className="text-[10px] text-[#888]">Receba no seu Express</p>
            </div>
          </motion.button>

          <motion.button
            onClick={() => {
              setMethod("iban");
              setStep("form");
              audio.playButtonClick();
            }}
            className="w-full rounded-xl p-4 text-left flex items-center gap-3 cursor-pointer transition-colors"
            style={{
              background: "rgba(25,25,35,0.9)",
              border: "1px solid rgba(100,100,120,0.25)",
            }}
            whileTap={{ scale: 0.98 }}
          >
            <img
              src={MULTICAIXA_LOGO}
              alt="Multicaixa"
              className="w-10 h-10 rounded-lg object-contain bg-white/5 p-1"
            />
            <div>
              <p className="font-bold text-white text-sm">Registrar IBAN</p>
              <p className="text-[10px] text-[#888]">Transferência bancária directa</p>
            </div>
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto py-4"
      style={bgStyle}
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
      <motion.div
        className="relative z-10 w-[calc(100%-40px)] max-w-[380px] mx-auto rounded-2xl px-6 py-8"
        style={{
          background: "linear-gradient(180deg, rgba(20,25,35,0.95), rgba(15,18,25,0.97))",
          border: "1px solid rgba(100,120,140,0.2)",
          boxShadow: "0 8px 40px rgba(0,0,0,0.5)",
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <button
          onClick={() => {
            setMethod("none");
            setStep("choose");
          }}
          className="text-xs mb-3 text-[#888] hover:text-white transition-colors cursor-pointer"
        >
          ← Voltar
        </button>

        <h2
          className="text-lg font-bold text-white mb-5"
          style={{ fontFamily: "'Russo One', sans-serif" }}
        >
          {method === "express" ? "Multicaixa Express" : "Registrar IBAN"}
        </h2>

        {method === "express" ? (
          <div className="space-y-3">
            <div>
              <label className="text-[10px] mb-1 block text-[#888]">
                Número Express
              </label>
              <input
                type="tel"
                value={expressPhone}
                onChange={(e) => {
                  setExpressPhone(formatPhone(e.target.value));
                  setErrors((prev) => ({ ...prev, express: "" }));
                }}
                placeholder="9XX XXX XXX"
                className="w-full rounded-xl px-4 py-3 text-white text-base outline-none"
                style={{
                  background: "rgba(25,25,35,0.9)",
                  border: errors.express
                    ? "1px solid #ef4444"
                    : "1px solid rgba(100,100,120,0.3)",
                }}
                maxLength={11}
              />
              {errors.express && (
                <p className="text-[11px] mt-1 text-[#ef4444]">{errors.express}</p>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="text-[10px] mb-1 block text-[#888]">
                Nome completo
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => {
                  setFullName(e.target.value.slice(0, 100));
                  setErrors((prev) => ({ ...prev, fullName: "" }));
                }}
                placeholder="Nome do titular"
                className="w-full rounded-xl px-4 py-3 text-white text-base outline-none"
                style={{
                  background: "rgba(25,25,35,0.9)",
                  border: errors.fullName
                    ? "1px solid #ef4444"
                    : "1px solid rgba(100,100,120,0.3)",
                }}
                maxLength={100}
              />
              {errors.fullName && (
                <p className="text-[11px] mt-1 text-[#ef4444]">{errors.fullName}</p>
              )}
            </div>

            <div>
              <label className="text-[10px] mb-1 block text-[#888]">
                Número de telefone
              </label>
              <input
                type="tel"
                value={ibanPhone}
                onChange={(e) => {
                  setIbanPhone(formatPhone(e.target.value));
                  setErrors((prev) => ({ ...prev, phone: "" }));
                }}
                placeholder="9XX XXX XXX"
                className="w-full rounded-xl px-4 py-3 text-white text-base outline-none"
                style={{
                  background: "rgba(25,25,35,0.9)",
                  border: errors.phone
                    ? "1px solid #ef4444"
                    : "1px solid rgba(100,100,120,0.3)",
                }}
                maxLength={11}
              />
              {errors.phone && (
                <p className="text-[11px] mt-1 text-[#ef4444]">{errors.phone}</p>
              )}
            </div>

            <div>
              <label className="text-[10px] mb-1 block text-[#888]">IBAN</label>
              <input
                type="text"
                value={ibanNumber}
                onChange={(e) => {
                  setIbanNumber(formatIban(e.target.value));
                  setErrors((prev) => ({ ...prev, iban: "" }));
                }}
                placeholder="AO06 XXXX XXXX XXXX XXXX XXXX X"
                className="w-full rounded-xl px-4 py-3 text-white text-base outline-none"
                style={{
                  background: "rgba(25,25,35,0.9)",
                  border: errors.iban
                    ? "1px solid #ef4444"
                    : "1px solid rgba(100,100,120,0.3)",
                }}
                maxLength={31}
              />
              {errors.iban && (
                <p className="text-[11px] mt-1 text-[#ef4444]">{errors.iban}</p>
              )}
            </div>
          </div>
        )}

        <motion.button
          onClick={() => {
            if (document.activeElement instanceof HTMLElement) {
              document.activeElement.blur();
            }
            if (validate()) {
              setStep("processing");
              audio.playButtonClick();
            }
          }}
          className="w-full py-3.5 rounded-xl text-base font-bold mt-6 cursor-pointer"
          style={{
            background: "linear-gradient(135deg, #FFD700, #DAA520, #FF8C00)",
            color: "#1a0505",
            fontFamily: "'Russo One', sans-serif",
          }}
          whileTap={{ scale: 0.97 }}
        >
          Confirmar Levantamento
        </motion.button>
      </motion.div>
    </div>
  );
};
