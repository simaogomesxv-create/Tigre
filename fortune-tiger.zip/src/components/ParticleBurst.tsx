import { motion } from "motion/react";

interface SparkleParticleProps {
  index: number;
}

export const SparkleParticle = ({ index }: SparkleParticleProps) => {
  const angle = (index / 8) * Math.PI * 2;
  const dist = 30 + Math.random() * 40;
  const size = 3 + Math.random() * 4;
  const bg =
    index % 3 === 0
      ? "hsl(45, 100%, 60%)"
      : index % 3 === 1
      ? "hsl(35, 100%, 50%)"
      : "hsl(45, 100%, 80%)";

  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: size,
        height: size,
        background: bg,
        boxShadow: `0 0 ${size * 2}px hsl(45, 100%, 60%)`,
        left: "50%",
        top: "50%",
      }}
      initial={{ x: 0, y: 0, opacity: 1, scale: 0 }}
      animate={{
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist,
        opacity: [0, 1, 1, 0],
        scale: [0, 1.5, 1, 0],
      }}
      transition={{
        duration: 1.2,
        repeat: Infinity,
        delay: index * 0.08,
        ease: "easeOut",
      }}
    />
  );
};
