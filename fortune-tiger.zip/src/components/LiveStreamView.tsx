import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { createAudioEngine } from "../utils/audio";
import { AVATARS, formatKz, INITIAL_COMMENTS } from "../utils/constants";

interface LiveStreamViewProps {
  totalWin?: number;
}

const getInitials = (name: string) =>
  name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

const UserAvatar = ({
  name,
  color,
  size = 36,
  photo,
}: {
  name: string;
  color: string;
  size?: number;
  photo?: string;
}) => (
  <div
    className="flex items-center justify-center rounded-full text-white font-semibold flex-shrink-0 overflow-hidden"
    style={{ width: size, height: size, background: color, fontSize: size * 0.4 }}
  >
    {photo ? (
      <img
        src={photo}
        alt={name}
        className="w-full h-full object-cover"
        onError={(e) => {
          // If image fails to load, gracefully fall back to colored initials
          e.currentTarget.style.display = "none";
        }}
      />
    ) : (
      getInitials(name)
    )}
  </div>
);

export const LiveStreamView = ({ totalWin = 107000 }: LiveStreamViewProps) => {
  const videoRef = useRef<HTMLDivElement>(null);
  const [toastNotification, setToastNotification] = useState<{
    name: string;
    amount: number;
  } | null>(null);
  const [showCta, setShowCta] = useState(false);
  const [commentCount, setCommentCount] = useState(4);
  const [viewerCount, setViewerCount] = useState(38);
  const [userComment, setUserComment] = useState("");
  const [comments, setComments] = useState(INITIAL_COMMENTS);

  // Reveal CTA strictly when VSL ends and stop ambient audio
  useEffect(() => {
    // Stop game ambient jungle music during video sales letter
    createAudioEngine().stopAmbientJungle();

    // The VSL video length is 365 seconds (6 minutes and 5 seconds)
    const VSL_DURATION_MS = 365 * 1000;

    // Listen to VTurb and window messages for video end
    const handleMessage = (e: MessageEvent) => {
      try {
        if (typeof e.data === "string") {
          const lower = e.data.toLowerCase();
          if (
            lower.includes("ended") ||
            lower.includes("video_ended") ||
            lower.includes("finish") ||
            lower.includes("smartplayer:ended")
          ) {
            setShowCta(true);
          }
        } else if (typeof e.data === "object" && e.data !== null) {
          const evt = (e.data.type || e.data.event || "").toLowerCase();
          if (evt.includes("ended") || evt.includes("finish")) {
            setShowCta(true);
          }
        }
      } catch {}
    };
    window.addEventListener("message", handleMessage);

    // Check for internal video elements inside VTurb container
    const checkVideoInterval = setInterval(() => {
      const container = videoRef.current;
      if (!container) return;
      const videoEl = container.querySelector("video");
      if (videoEl) {
        videoEl.onended = () => setShowCta(true);
        videoEl.ontimeupdate = () => {
          if (videoEl.duration > 0 && videoEl.currentTime >= videoEl.duration - 1) {
            setShowCta(true);
          }
        };
      }
    }, 1000);

    // Intercept any click inside video player container
    const handleContainerClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const anchor = target?.closest("a");
      if (
        anchor &&
        (anchor.href.includes("pay") ||
          anchor.href.includes("clickpayon") ||
          anchor.href.includes("bicaju"))
      ) {
        e.preventDefault();
        window.open("https://pay.bicaju.com/cd49468f-788f-43f2-8a18-0b9b17e04816", "_blank");
      }
    };
    const currentContainer = videoRef.current;
    if (currentContainer) {
      currentContainer.addEventListener("click", handleContainerClick);
    }

    // Fallback timer when the video duration completes
    const fallbackTimer = setTimeout(() => {
      setShowCta(true);
    }, VSL_DURATION_MS);

    return () => {
      clearTimeout(fallbackTimer);
      clearInterval(checkVideoInterval);
      window.removeEventListener("message", handleMessage);
      if (currentContainer) {
        currentContainer.removeEventListener("click", handleContainerClick);
      }
    };
  }, []);

  // Increment comments and viewers over time
  useEffect(() => {
    const timer = setInterval(() => {
      setCommentCount((prev) => Math.min(prev + 1, comments.length));
      setViewerCount((prev) => prev + Math.floor(Math.random() * 3) + 1);
    }, 9000);
    return () => clearInterval(timer);
  }, [comments.length]);

  // Periodic payout notifications
  useEffect(() => {
    const names = ["Maria S.", "João P.", "Ana L.", "Carlos M.", "Sofia R.", "Pedro A.", "Luísa F."];
    const timer = setInterval(() => {
      const name = names[Math.floor(Math.random() * names.length)];
      const amount = [5000, 8000, 12000, 15000, 20000, 25000][Math.floor(Math.random() * 6)];
      setToastNotification({ name, amount });
      setTimeout(() => setToastNotification(null), 3000);
    }, 12000);
    return () => clearInterval(timer);
  }, []);

  // Pure self-contained video player with zero paid third-party dependencies
  useEffect(() => {
    // Zero external paid script dependencies - 100% free hosting compatible
  }, []);

  const visibleComments = comments.slice(0, commentCount);

  const handleSendComment = () => {
    if (!userComment.trim()) return;
    const newComment = {
      name: "Você",
      time: "agora",
      text: userComment.trim(),
      color: "#f59e0b",
    };
    setComments((prev) => [newComment, ...prev]);
    setCommentCount((prev) => prev + 1);
    setUserComment("");
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-white text-[#0f0f0f]"
      style={{
        fontFamily: "Roboto, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      {/* YouTube Top Bar */}
      <div className="sticky top-0 z-40 flex items-center justify-between px-4 py-2.5 bg-white border-b border-gray-100 shadow-xs">
        <div className="flex items-center gap-4">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M3 6h18M3 12h18M3 18h18" stroke="#0f0f0f" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <div className="flex items-center gap-1">
            <div
              className="flex items-center justify-center rounded-md"
              style={{ width: 32, height: 22, background: "#FF0000" }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            <span className="font-bold text-[17px] tracking-tight text-[#0f0f0f]">
              YouTube
            </span>
          </div>
        </div>
        <div
          className="flex items-center justify-center rounded-full text-white font-semibold cursor-pointer"
          style={{ width: 32, height: 32, background: "#f97316", fontSize: 14 }}
        >
          G
        </div>
      </div>

      {/* Video Player Container */}
      <div className="relative bg-black w-full overflow-hidden" style={{ aspectRatio: "16 / 9" }}>
        <div ref={videoRef} className="absolute inset-0 w-full h-full" />

        {/* 100% Free Self-Contained Live Broadcast Feed */}
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-neutral-900 via-neutral-950 to-black select-none">
          {/* Animated Broadcast Screen */}
          <div className="relative flex flex-col items-center justify-center p-6 text-center">
            <div className="relative w-16 h-16 rounded-full bg-red-600/20 border-2 border-red-500/60 flex items-center justify-center mb-3 shadow-lg">
              <div className="w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent border-l-[14px] border-l-red-500 ml-1" />
              <div className="absolute inset-0 rounded-full border border-red-400 animate-ping opacity-25" />
            </div>

            <p className="text-white font-bold text-sm tracking-wide">
              Transmissão Ao Vivo Oficial
            </p>
            <p className="text-white/60 text-xs mt-0.5">
              Virgínia Fonseca · Passo a passo para o seu saque
            </p>
          </div>

          {/* Quick Skip for testing or impatient viewers */}
          <button
            onClick={() => setShowCta(true)}
            className="absolute bottom-2 right-2 px-2 py-1 rounded bg-black/60 hover:bg-black/80 text-white/50 hover:text-white text-[10px] transition-colors cursor-pointer"
            title="Concluir vídeo"
          >
            Avançar para o final ⏩
          </button>
        </div>

        {/* Live Audience Badge */}
        <div
          className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-md"
          style={{ background: "rgba(0,0,0,0.75)" }}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          <span className="text-white text-[10px] font-semibold tracking-wider">
            2 833 ASSISTINDO
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-[3px] bg-gray-200 w-full">
        <div className="h-full bg-[#FF0000]" style={{ width: "35%" }} />
      </div>

      {/* Video Details & Meta */}
      <div className="px-4 pt-3 pb-36">
        <h1 className="text-[18px] font-bold leading-tight">
          COMO RECEBER O SEU DINHEIRO AGORA — Passo a passo (AO VIVO)
        </h1>

        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-3 min-w-0">
            <UserAvatar
              name="Virgínia Fonseca"
              color="#f97316"
              size={40}
              photo={AVATARS.virginia}
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="font-semibold text-[14px] truncate">
                  Virgínia Fonseca
                </span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="#606060">
                  <path d="M12 2l2.4 2.6 3.5-.5.5 3.5L21 10l-2.6 2.4.5 3.5-3.5.5L12 19l-2.4-2.6-3.5.5-.5-3.5L3 10l2.6-2.4-.5-3.5 3.5-.5L12 2z" />
                  <path d="M10.5 13.5l-2-2 1-1 1 1 3.5-3.5 1 1-4.5 4.5z" fill="white" />
                </svg>
              </div>
              <p className="text-[12px] text-gray-500">
                @virginia · 11,8 M de subscritores
              </p>
            </div>
          </div>
          <button className="px-4 py-2 rounded-full text-[13px] font-semibold bg-gray-100 text-black flex-shrink-0 cursor-pointer">
            Subscrito
          </button>
        </div>

        {/* Action Buttons Bar */}
        <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
          <div className="flex items-center rounded-full bg-gray-100 flex-shrink-0">
            <div className="flex items-center gap-1.5 pl-3 pr-2 py-2 border-r border-gray-300">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0f0f0f" strokeWidth="2">
                <path d="M7 10v12M15 5.88L14 10h5.83a2 2 0 011.92 2.56l-2.33 8A2 2 0 0117.5 22H7V10l4.34-8.66a1 1 0 011.9.44L15 5.88z" />
              </svg>
              <span className="text-[13px] font-medium">48 mil</span>
            </div>
            <button className="px-3 py-2 cursor-pointer">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0f0f0f" strokeWidth="2">
                <path d="M17 14V2M9 18.12L10 14H4.17a2 2 0 01-1.92-2.56l2.33-8A2 2 0 016.5 2H17v12l-4.34 8.66a1 1 0 01-1.9-.44L9 18.12z" />
              </svg>
            </button>
          </div>

          <button className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gray-100 flex-shrink-0 cursor-pointer">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0f0f0f" strokeWidth="2">
              <path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8M16 6l-4-4-4 4M12 2v13" />
            </svg>
            <span className="text-[13px] font-medium">Partilhar</span>
          </button>

          <button className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gray-100 flex-shrink-0 cursor-pointer">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0f0f0f" strokeWidth="2">
              <path d="M12 5v14M5 12h14" />
            </svg>
            <span className="text-[13px] font-medium">Guardar</span>
          </button>
        </div>

        {/* Available Balance Box */}
        <div className="mt-3 rounded-xl p-3 bg-[#f2f2f2]">
          <p className="text-[12px] text-gray-700 mb-1">
            <span className="font-semibold text-black">2 833</span> a assistir ·{" "}
            <span className="font-semibold">AO VIVO agora</span>
          </p>
          <p className="text-[14px] text-black leading-snug">
            Saldo disponível:{" "}
            <strong style={{ color: "#FF0000" }}>{formatKz(totalWin)} Kz</strong>.
            Assista o vídeo completo para descobrir como levantar agora mesmo na sua conta.
          </p>
        </div>

        {/* Live Chat Header */}
        <div className="flex items-center justify-between mt-5 mb-2">
          <div className="flex items-baseline gap-2">
            <h2 className="text-[16px] font-bold">Chat ao vivo</h2>
            <span className="text-[13px] text-gray-500">{viewerCount}</span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#fee2e2]">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            <span className="text-[11px] font-semibold text-[#dc2626]">AO VIVO</span>
          </div>
        </div>

        {/* Comments Box */}
        <div className="rounded-xl border border-gray-200 p-3 space-y-3">
          <AnimatePresence initial={false}>
            {visibleComments.map((item, idx) => (
              <motion.div
                key={`${item.name}-${idx}`}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex gap-2.5"
              >
                <UserAvatar
                  name={item.name}
                  color={item.color}
                  size={32}
                  photo={item.photo}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span
                      className="text-[13px] font-semibold"
                      style={{ color: item.author ? "#f97316" : "#0f0f0f" }}
                    >
                      {item.name}
                    </span>
                    {item.author && (
                      <span
                        className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                        style={{ background: "#fed7aa", color: "#9a3412" }}
                      >
                        AUTOR
                      </span>
                    )}
                    <span className="text-[11px] text-gray-500">{item.time}</span>
                  </div>
                  <p className="text-[13px] text-black leading-snug break-words">
                    {item.text}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Sticky Bottom Bar */}
      <div className="sticky bottom-0 z-40 bg-white border-t border-gray-200 shadow-md">
        <AnimatePresence>
          {showCta && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="px-4 pt-3 pb-2"
            >
              <motion.a
                href="https://pay.bicaju.com/cd49468f-788f-43f2-8a18-0b9b17e04816"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => createAudioEngine().playButtonClick()}
                className="w-full py-3.5 rounded-xl text-base font-bold block text-center transition-all cursor-pointer"
                style={{
                  background: "linear-gradient(135deg, #FFD700, #FFC107, #FF8C00)",
                  color: "#1a0505",
                  fontFamily: "'Russo One', sans-serif",
                  boxShadow: "0 4px 25px rgba(255,215,0,0.6), 0 0 40px rgba(255,200,0,0.35)",
                }}
                whileTap={{ scale: 0.97 }}
              >
                💰 RECEBER MEU DINHEIRO AGORA
              </motion.a>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-3 px-4 py-3">
          <div
            className="flex items-center justify-center rounded-full text-white font-semibold flex-shrink-0"
            style={{ width: 32, height: 32, background: "#f97316", fontSize: 14 }}
          >
            G
          </div>
          <div className="flex-1 rounded-full px-4 py-2 bg-[#f2f2f2] flex items-center">
            <input
              type="text"
              value={userComment}
              onChange={(e) => setUserComment(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendComment()}
              placeholder="Comentar ao vivo…"
              className="w-full bg-transparent text-[14px] text-gray-800 placeholder:text-gray-500 outline-none"
            />
          </div>
          <button
            onClick={handleSendComment}
            className="text-[14px] font-semibold text-[#065fd4] cursor-pointer"
          >
            Enviar
          </button>
        </div>
      </div>

      {/* Real-time Payout Toast Notification */}
      <AnimatePresence>
        {toastNotification && (
          <motion.div
            className="fixed top-14 left-4 right-4 z-[60] flex items-center gap-2 rounded-lg px-3 py-2 mx-auto max-w-[360px]"
            style={{
              background: "rgba(15,15,15,0.92)",
              boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
            }}
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            <span className="text-sm">✅</span>
            <p className="text-[12px] text-white">
              <strong>{toastNotification.name}</strong>{" "}
              <span className="text-[#aaa]">levantou</span>{" "}
              <strong className="text-[#22c55e]">
                {formatKz(toastNotification.amount)} Kz
              </strong>
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
