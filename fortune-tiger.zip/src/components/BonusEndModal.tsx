import { motion } from "motion/react";
import { useEffect } from "react";
import { createAudioEngine } from "../utils/audio";
import { formatKz, TEMPLE_BG } from "../utils/constants";

interface BonusEndModalProps {
  totalWin: number;
  onContinue: () => void;
}

export const BonusEndModal = ({ totalWin, onContinue }: BonusEndModalProps) => {
  const audio = createAudioEngine();

  useEffect(() => {
    audio.playBonusEnd();
  }, []);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto py-4"
      style={{
        backgroundImage: `url(${TEMPLE_BG})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />

      <motion.div
        className="relative z-10 w-[calc(100%-40px)] max-w-[380px] mx-auto rounded-2xl p-6 text-center"
        style={{
          background: "linear-gradient(180deg, rgba(20,25,35,0.95), rgba(15,18,25,0.97))",
          border: "1px solid rgba(218,165,32,0.3)",
          boxShadow: "0 0 60px rgba(255,215,0,0.2)",
        }}
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
      >
        <motion.div
          className="text-5xl mb-3 select-none"
          animate={{ rotate: [0, -10, 10, -10, 0], scale: [1, 1.1, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          🏆
        </motion.div>

        <h2
          className="text-xl font-bold mb-1"
          style={{
            background: "linear-gradient(180deg, #FFD700, #DAA520)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            fontFamily: "'Russo One', sans-serif",
          }}
        >
          BÓNUS CONCLUÍDO!
        </h2>
        <p className="text-xs mb-4 text-[#888]">
          As suas 10 jogadas grátis terminaram
        </p>

        <div
          className="h-px mb-3"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(218,165,32,0.4), transparent)",
          }}
        />

        <p className="text-xs mb-1 text-[#999]">Total ganho</p>
        <motion.p
          className="text-4xl font-bold mb-1"
          style={{
            background: "linear-gradient(180deg, #22c55e, #16a34a)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            fontFamily: "'Orbitron', sans-serif",
            filter: "drop-shadow(0 0 10px rgba(34,197,94,0.4))",
          }}
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {formatKz(totalWin)} Kz
        </motion.p>
        <p className="text-xs mb-5 text-[#666]">disponível para levantamento</p>

        <div
          className="h-px mb-5"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(218,165,32,0.4), transparent)",
          }}
        />

        <motion.button
          onClick={() => {
            audio.playButtonClick();
            onContinue();
          }}
          className="w-full py-4 rounded-xl text-base font-bold cursor-pointer transition-transform"
          style={{
            background: "linear-gradient(135deg, #FFD700, #DAA520, #FF8C00)",
            color: "#1a0505",
            fontFamily: "'Russo One', sans-serif",
            boxShadow: "0 0 30px rgba(255,215,0,0.4)",
          }}
          whileTap={{ scale: 0.97 }}
          animate={{
            boxShadow: [
              "0 0 20px rgba(255,215,0,0.3)",
              "0 0 40px rgba(255,215,0,0.6)",
              "0 0 20px rgba(255,215,0,0.3)",
            ],
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          💰 Levantar os meus ganhos
        </motion.button>
      </motion.div>
    </div>
  );
};
