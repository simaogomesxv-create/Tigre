import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createAudioEngine } from "../utils/audio";
import { TEMPLE_BG, TIGER_MASCOT } from "../utils/constants";

const CheckItem = ({ children }: { children: React.ReactNode }) => (
  <div className="flex items-start gap-3">
    <div className="w-5 h-5 rounded-full bg-[#22c55e] flex items-center justify-center shrink-0 mt-0.5">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#161412" strokeWidth="3">
        <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
    <span className="text-[#fbf5e6] text-sm leading-tight">{children}</span>
  </div>
);

export const WelcomePage = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<"welcome" | "register">("welcome");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const audio = createAudioEngine();

  const formatPhone = (val: string) => {
    const raw = val.replace(/\D/g, "").slice(0, 9);
    if (raw.length <= 3) return raw;
    if (raw.length <= 6) return `${raw.slice(0, 3)} ${raw.slice(3)}`;
    return `${raw.slice(0, 3)} ${raw.slice(3, 6)} ${raw.slice(6)}`;
  };

  const handleRegister = () => {
    const errs: { name?: string; phone?: string } = {};
    const trimmedName = name.trim();
    const cleanPhone = phone.trim().replace(/\s/g, "");

    if (!trimmedName || trimmedName.length < 2) {
      errs.name = "Insira o seu nome completo";
    }
    if (!cleanPhone || !/^9\d{8}$/.test(cleanPhone)) {
      errs.phone = "Insira um número válido (9XX XXX XXX)";
    }

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    setErrors({});
    setShowSuccessModal(true);
    audio.playSuccess();
  };

  return (
    <div
      className="min-h-[100vh] min-h-[100dvh] flex items-center justify-center bg-cover bg-center bg-no-repeat p-4 overflow-y-auto"
      style={{
        backgroundImage: `url(${TEMPLE_BG})`,
        backgroundColor: "hsl(30, 10%, 8%)",
      }}
    >
      <AnimatePresence mode="wait">
        {step === "welcome" ? (
          <motion.div
            key="welcome"
            className="card-dark rounded-2xl max-w-md w-full px-6 py-8 flex flex-col items-center text-center shadow-2xl relative z-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <img
              src={TIGER_MASCOT}
              alt="Fortune Tiger mascot"
              className="w-32 h-auto object-contain mb-4 select-none drop-shadow-2xl"
            />
            <h1
              className="text-2xl font-extrabold text-gold-gradient mb-1 tracking-wide"
              style={{ fontFamily: "'Russo One', sans-serif" }}
            >
              PARABÉNS!
            </h1>
            <p className="text-[#fbf5e6] font-bold text-sm mb-0.5">
              Bem-vindo ao Fortune Tiger
            </p>
            <p className="text-[#b3a89a] text-xs mb-6">
              A sua conta foi selecionada para uma oferta exclusiva
            </p>

            <div
              className="w-full rounded-xl px-4 py-3 mb-5"
              style={{
                background: "hsla(45, 50%, 25%, 0.2)",
                border: "1px solid hsla(45, 50%, 25%, 0.3)",
              }}
            >
              <p className="text-[#b3a89a] text-xs mb-0.5">Bónus de Boas-Vindas</p>
              <p
                className="text-2xl font-extrabold mb-1"
                style={{
                  background: "linear-gradient(180deg, hsl(45, 100%, 55%), hsl(35, 100%, 45%))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "'Russo One', sans-serif",
                }}
              >
                🎰 10 Jogadas
              </p>
              <p className="text-[#b3a89a] text-xs">
                Cada jogada com aposta de{" "}
                <strong className="text-[#fbf5e6]">1.000 Kz</strong>
              </p>
            </div>

            <div className="w-full text-left space-y-3 mb-6">
              <CheckItem>
                Jogue <strong className="text-[#ffcc33]">10 rodadas gratuitas</strong> no Fortune Tiger
              </CheckItem>
              <CheckItem>
                Acumule ganhos com <strong className="text-[#ffcc33]">multiplicadores elevados</strong>
              </CheckItem>
              <CheckItem>
                Levante os seus ganhos <strong className="text-[#ffcc33]">após as jogadas</strong>
              </CheckItem>
            </div>

            <button
              onClick={() => {
                audio.playButtonClick();
                setStep("register");
              }}
              className="btn-gold-gradient w-full py-4 rounded-xl text-[#161412] font-bold text-lg flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg cursor-pointer"
              style={{ fontFamily: "'Russo One', sans-serif" }}
            >
              🎰 Jogar Agora
            </button>

            <p className="text-[#888] text-[10px] mt-3">
              Oferta limitada · Apenas para novas contas
            </p>
          </motion.div>
        ) : (
          <motion.div
            key="register"
            className="card-dark rounded-2xl max-w-md w-full px-6 py-8 flex flex-col items-center text-center shadow-2xl relative z-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <button
              onClick={() => {
                audio.playButtonClick();
                setStep("welcome");
              }}
              className="self-start text-xs text-[#888] mb-3 hover:text-white transition-colors cursor-pointer"
            >
              ← Voltar
            </button>

            <img
              src={TIGER_MASCOT}
              alt="Fortune Tiger mascot"
              className="w-20 h-auto object-contain mb-3 select-none drop-shadow-xl"
            />
            <h1
              className="text-2xl font-extrabold text-gold-gradient mb-1 tracking-wide"
              style={{ fontFamily: "'Russo One', sans-serif" }}
            >
              Cadastre-se
            </h1>
            <p className="text-[#b3a89a] text-sm mb-6">
              e ganhe{" "}
              <span className="text-[#22c55e] font-bold">10 rodadas grátis</span> no
              Fortune Tiger
            </p>

            <div className="w-full space-y-4 mb-6">
              <div className="text-left">
                <label className="text-[10px] uppercase tracking-widest text-[#888] font-semibold mb-1 block">
                  Nome Completo
                </label>
                <input
                  type="text"
                  placeholder="Seu nome"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value.slice(0, 100));
                    if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                  }}
                  className="w-full rounded-xl px-4 py-3 text-base text-white placeholder:text-[#666] outline-none transition-all"
                  style={{
                    background: "hsl(30, 10%, 14%)",
                    border: errors.name
                      ? "1px solid hsl(0, 84%, 60%)"
                      : "1px solid hsla(45, 50%, 25%, 0.4)",
                  }}
                  maxLength={100}
                />
                {errors.name && (
                  <p className="text-[11px] mt-1 text-[#ef4444]">{errors.name}</p>
                )}
              </div>

              <div className="text-left">
                <label className="text-[10px] uppercase tracking-widest text-[#888] font-semibold mb-1 block">
                  Número de Telefone
                </label>
                <input
                  type="tel"
                  placeholder="9XX XXX XXX"
                  value={phone}
                  onChange={(e) => {
                    setPhone(formatPhone(e.target.value));
                    if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                  }}
                  className="w-full rounded-xl px-4 py-3 text-base text-white placeholder:text-[#666] outline-none transition-all"
                  style={{
                    background: "hsl(30, 10%, 14%)",
                    border: errors.phone
                      ? "1px solid hsl(0, 84%, 60%)"
                      : "1px solid hsla(45, 50%, 25%, 0.4)",
                  }}
                  maxLength={11}
                />
                {errors.phone && (
                  <p className="text-[11px] mt-1 text-[#ef4444]">{errors.phone}</p>
                )}
              </div>
            </div>

            <button
              onClick={handleRegister}
              className="btn-gold-gradient w-full py-4 rounded-xl text-[#161412] font-bold text-lg flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg cursor-pointer"
              style={{ fontFamily: "'Russo One', sans-serif" }}
            >
              🎰 Cadastrar e Jogar
            </button>

            <p className="text-[#888] text-[10px] mt-4">
              Ao cadastrar-se, você aceita os termos e condições
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Dialog Modal */}
      <AnimatePresence>
        {showSuccessModal && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/70 backdrop-blur-xs"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="card-dark rounded-2xl max-w-sm w-full px-6 py-8 flex flex-col items-center text-center shadow-2xl relative"
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              transition={{ type: "spring", damping: 20 }}
            >
              <img
                src={TIGER_MASCOT}
                alt="Fortune Tiger mascot"
                className="w-24 h-auto object-contain mb-3 select-none"
              />
              <span className="text-4xl mb-2 select-none">🎉</span>
              <h2
                className="text-2xl font-extrabold text-gold-gradient mb-2"
                style={{ fontFamily: "'Russo One', sans-serif" }}
              >
                Parabéns!
              </h2>
              <p className="text-[#fbf5e6] font-semibold text-sm mb-1">
                Cadastro realizado com sucesso!
              </p>
              <p className="text-[#b3a89a] text-sm mb-4">
                Você ganhou{" "}
                <span className="text-[#22c55e] font-bold">10 rodadas grátis</span> no
                Fortune Tiger
              </p>

              <div className="flex items-center gap-2 mb-6">
                <span className="text-2xl select-none">🎰</span>
                <span
                  className="text-3xl font-extrabold text-[#ffd24d]"
                  style={{ fontFamily: "'Russo One', sans-serif" }}
                >
                  10 Rodadas Grátis
                </span>
              </div>

              <button
                onClick={() => {
                  if (document.activeElement instanceof HTMLElement) {
                    document.activeElement.blur();
                  }
                  setTimeout(() => navigate("/game"), 100);
                }}
                className="btn-gold-gradient w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                style={{
                  color: "hsl(30, 10%, 8%)",
                  fontFamily: "'Russo One', sans-serif",
                }}
              >
                🎰 Começar a Jogar
              </button>

              <p className="text-[#888] text-[10px] mt-4">
                Ao cadastrar-se, você aceita os termos e condições
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
