import { useEffect } from "react";
import { useLocation } from "react-router-dom";

export const NotFoundPage = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#141210] text-[#fbf5e6] p-4">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-bold font-mono">404</h1>
        <p className="mb-4 text-xl text-[#b3a89a]">Oops! Page not found</p>
        <a
          href="/"
          className="text-[#ffd24d] underline hover:text-[#ffcc33] font-medium"
        >
          Return to Home
        </a>
      </div>
    </div>
  );
};
