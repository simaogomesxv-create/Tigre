import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useRef, useState } from "react";
import { BonusEndModal } from "../components/BonusEndModal";
import { ReelColumn } from "../components/ReelColumn";
import { StatusBanner } from "../components/StatusBanner";
import { WithdrawModal } from "../components/WithdrawModal";
import { SlotGameState, SymbolType } from "../types/game";
import { createAudioEngine } from "../utils/audio";
import {
  createRandomGrid,
  formatKz,
  generateLosingGrid,
  generateWinningGrid,
  SPIN_SEQUENCE,
  TEMPLE_BG,
  TIGER_MASCOT,
} from "../utils/constants";

const BET_AMOUNT = 500;

export const GamePage = () => {
  const [totalWin, setTotalWin] = useState(0);
  const [displayWin, setDisplayWin] = useState(0);
  const [spinCount, setSpinCount] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [grid, setGrid] = useState<SymbolType[][]>(createRandomGrid);
  const [gameState, setGameState] = useState<SlotGameState>("idle");
  const [showWinOverlay, setShowWinOverlay] = useState(false);
  const [winDetails, setWinDetails] = useState({ label: "", amount: 0, isMega: false });
  const [autoSpin, setAutoSpin] = useState(false);
  const [winLine, setWinLine] = useState<number[] | null>(null);
  const [glowBalance, setGlowBalance] = useState(false);
  const [pageMode, setPageMode] = useState<"playing" | "bonus-end" | "withdraw">("playing");
  const [gridShake, setGridShake] = useState(false);
  const [turbo, setTurbo] = useState(false);
  const [isMuted, setIsMuted] = useState(() => createAudioEngine().getMuteState().isMuted);
  const [isAmbientMuted, setIsAmbientMuted] = useState(() => createAudioEngine().getMuteState().isAmbientMuted);

  const autoSpinRef = useRef(false);
  const audio = createAudioEngine();
  const spinDuration = turbo ? 800 : 1500;

  // Start ambient jungle audio and handle browser interaction unlock
  useEffect(() => {
    audio.startAmbientJungle();

    const unlockAudio = () => {
      audio.getContext();
      audio.startAmbientJungle();
    };

    window.addEventListener("pointerdown", unlockAudio, { once: true });
    window.addEventListener("keydown", unlockAudio, { once: true });

    return () => {
      audio.stopAmbientJungle();
      window.removeEventListener("pointerdown", unlockAudio);
      window.removeEventListener("keydown", unlockAudio);
    };
  }, []);

  // Smooth balance count-up animation
  useEffect(() => {
    if (displayWin === totalWin) return;
    const diff = totalWin - displayWin;
    const steps = 25;
    const stepVal = diff / steps;
    let current = displayWin;
    let step = 0;
    const interval = setInterval(() => {
      step++;
      current += stepVal;
      if (step >= steps) {
        setDisplayWin(totalWin);
        clearInterval(interval);
      } else {
        setDisplayWin(Math.round(current));
      }
    }, 30);
    return () => clearInterval(interval);
  }, [totalWin, displayWin]);

  // Handle spin execution
  const executeSpin = useCallback(() => {
    if (spinning || spinCount >= 10) return;

    const roundIndex = spinCount % 10;
    const outcome = SPIN_SEQUENCE[roundIndex];

    setSpinning(true);
    setGameState("spinning");
    setShowWinOverlay(false);
    setWinLine(null);
    setGridShake(true);

    audio.playSpinClick();
    setTimeout(() => setGridShake(false), 600);

    // Initial random shuffle during spin
    setGrid(createRandomGrid());

    setTimeout(() => {
      let finalGrid: SymbolType[][];
      let winRowIndex: number[] | null = null;

      if (outcome.win) {
        const generated = generateWinningGrid();
        finalGrid = generated.grid;
        winRowIndex = generated.winLine;
      } else {
        finalGrid = generateLosingGrid();
      }

      setGrid(finalGrid);
      setSpinning(false);
      audio.playReelStop(0);
      audio.playReelStop(0.14);
      audio.playReelStop(0.28);

      if (outcome.win) {
        const isMega = outcome.label === "SUPER MEGA GANHO" || outcome.label === "MEGA GANHO";
        setTimeout(() => {
          setGameState(isMega ? "mega-win" : "win");
          setWinDetails({
            label: outcome.label,
            amount: outcome.amount,
            isMega,
          });
          setGlowBalance(true);
          setWinLine(winRowIndex);

          if (isMega) {
            audio.playMegaWinSound();
          } else {
            audio.playWinSound();
          }
        }, 220);

        setTimeout(() => {
          setShowWinOverlay(true);
          audio.playCoinCount();
        }, 500);

        setTimeout(() => {
          setTotalWin((prev) => prev + outcome.amount);
        }, 750);

        setTimeout(() => {
          setShowWinOverlay(false);
          setGlowBalance(false);
          setWinLine(null);
          setGameState("idle");

          if (roundIndex === 9) {
            setTimeout(() => {
              setPageMode((curr) => (curr === "playing" ? "bonus-end" : curr));
            }, 500);
          }
        }, isMega ? 4000 : 2500);
      } else {
        setGameState("lose");
        setGridShake(true);
        audio.playLoseSound();

        setTimeout(() => setGridShake(false), 400);
        setTimeout(() => {
          setGameState("idle");
          if (roundIndex === 9) {
            setTimeout(() => {
              setPageMode((curr) => (curr === "playing" ? "bonus-end" : curr));
            }, 500);
          }
        }, 1200);
      }

      setSpinCount((prev) => prev + 1);
    }, spinDuration);
  }, [spinning, spinCount, audio, spinDuration]);

  // Keep autoSpinRef synchronized
  useEffect(() => {
    autoSpinRef.current = autoSpin;
  }, [autoSpin]);

  // Auto-spin interval trigger
  useEffect(() => {
    if (!autoSpin || spinning || spinCount >= 10) return;
    const timer = setTimeout(() => {
      if (autoSpinRef.current) {
        executeSpin();
      }
    }, 3000);
    return () => clearTimeout(timer);
  }, [autoSpin, spinning, executeSpin, spinCount]);

  if (pageMode === "withdraw") {
    return <WithdrawModal totalWin={totalWin} />;
  }

  if (pageMode === "bonus-end") {
    return (
      <BonusEndModal
        totalWin={totalWin}
        onContinue={() => setPageMode("withdraw")}
      />
    );
  }

  return (
    <div
      className="min-h-[100vh] min-h-[100dvh] flex flex-col items-center justify-start relative overflow-x-hidden overflow-y-auto"
      style={{
        minHeight: "-webkit-fill-available",
        backgroundColor: "hsl(30, 10%, 8%)",
      }}
    >
      {/* Background with Temple Image and subtle vignette */}
      <div className="absolute inset-0">
        <img
          src={TEMPLE_BG}
          alt=""
          className="w-full h-full object-cover select-none"
        />
      </div>
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.3) 100%)",
        }}
      />

      {/* 15 Floating Ambient Sparkles */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={`sparkle-${i}`}
          className="absolute rounded-full pointer-events-none z-20"
          style={{
            width: 2 + Math.random() * 3,
            height: 2 + Math.random() * 3,
            background: i % 3 === 0 ? "#FFD700" : i % 3 === 1 ? "#FF6B35" : "#fff",
            left: `${5 + Math.random() * 90}%`,
            top: `${10 + Math.random() * 80}%`,
            boxShadow: `0 0 ${4 + Math.random() * 6}px ${i % 3 === 0 ? "#FFD700" : "#FF6B35"}`,
          }}
          animate={{ opacity: [0, 0.8, 0], y: [0, -20, -40] }}
          transition={{
            duration: 3 + Math.random() * 3,
            repeat: Infinity,
            delay: Math.random() * 5,
          }}
        />
      ))}

      {/* Main Game Container */}
      <div className="relative z-10 w-full max-w-[420px] mx-auto flex flex-col pt-1 px-2 sm:px-0">
        {/* Top Sound & Brand Bar */}
        <div className="flex items-center justify-between px-3 py-1 mb-1">
          <div className="flex items-center gap-1.5">
            <span className="text-base">🐯</span>
            <span
              className="text-xs font-bold tracking-wider text-gold-gradient"
              style={{ fontFamily: "'Russo One', sans-serif" }}
            >
              FORTUNE TIGER
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Ambient Jungle Audio Toggle */}
            <button
              onClick={() => {
                const nextState = audio.toggleAmbientMute();
                setIsAmbientMuted(nextState);
                audio.playButtonClick();
              }}
              title={isAmbientMuted ? "Ativar som da selva" : "Silenciar som da selva"}
              className="w-7 h-7 rounded-full flex items-center justify-center text-xs transition-transform cursor-pointer"
              style={{
                background: isAmbientMuted
                  ? "rgba(40,40,40,0.7)"
                  : "linear-gradient(135deg, rgba(34,197,94,0.3), rgba(20,120,60,0.5))",
                border: isAmbientMuted
                  ? "1px solid rgba(255,255,255,0.15)"
                  : "1px solid rgba(34,197,94,0.6)",
                color: isAmbientMuted ? "#888" : "#22c55e",
              }}
            >
              {isAmbientMuted ? "🔇" : "🌴"}
            </button>

            {/* Master Sound Effects Toggle */}
            <button
              onClick={() => {
                const nextState = audio.toggleMute();
                setIsMuted(nextState);
                if (!nextState) audio.playButtonClick();
              }}
              title={isMuted ? "Ativar efeitos sonoros" : "Silenciar efeitos sonoros"}
              className="w-7 h-7 rounded-full flex items-center justify-center text-xs transition-transform cursor-pointer"
              style={{
                background: isMuted
                  ? "rgba(40,40,40,0.7)"
                  : "linear-gradient(135deg, rgba(218,165,32,0.3), rgba(184,134,11,0.5))",
                border: isMuted
                  ? "1px solid rgba(255,255,255,0.15)"
                  : "1px solid rgba(218,165,32,0.6)",
                color: isMuted ? "#888" : "#FFD700",
              }}
            >
              {isMuted ? "🔇" : "🔊"}
            </button>
          </div>
        </div>

        {/* Top HUD Bar */}
        <div
          className="flex items-center justify-between px-2 py-2 gap-2 rounded-xl mx-2 shadow-lg"
          style={{
            background: "linear-gradient(180deg, hsl(0, 60%, 18%), hsl(0, 60%, 10%))",
            border: "1px solid hsla(45, 80%, 50%, 0.4)",
          }}
        >
          {/* Jogadas */}
          <div className="flex-1 flex flex-col items-center">
            <span
              className="text-[8px] uppercase tracking-wider font-semibold"
              style={{ color: "hsl(45, 100%, 50%)" }}
            >
              Jogadas
            </span>
            <span
              className="font-bold text-xs"
              style={{
                color: "hsl(0, 0%, 100%)",
                fontFamily: "'Orbitron', sans-serif",
              }}
            >
              {spinCount}/10
            </span>
          </div>

          {/* Aposta Grátis */}
          <div
            className="flex-1 flex flex-col items-center px-2"
            style={{
              borderLeft: "1px solid hsla(45, 80%, 50%, 0.3)",
              borderRight: "1px solid hsla(45, 80%, 50%, 0.3)",
            }}
          >
            <span
              className="text-[8px] uppercase tracking-wider font-semibold"
              style={{ color: "hsl(45, 100%, 50%)" }}
            >
              Aposta Grátis
            </span>
            <span
              className="font-bold text-xs"
              style={{
                color: "hsl(0, 0%, 100%)",
                fontFamily: "'Orbitron', sans-serif",
              }}
            >
              {formatKz(BET_AMOUNT)} Kz
            </span>
          </div>

          {/* Saldo */}
          <div className="flex-1 flex flex-col items-center">
            <span
              className="text-[8px] uppercase tracking-wider font-semibold"
              style={{ color: "hsl(45, 100%, 50%)" }}
            >
              Saldo
            </span>
            <div className="flex items-center gap-1">
              <span className="text-[10px] select-none">💰</span>
              <span
                className={`font-bold text-xs ${glowBalance ? "glow-gold" : ""}`}
                style={{
                  color: "hsl(140, 70%, 45%)",
                  fontFamily: "'Orbitron', sans-serif",
                }}
              >
                {formatKz(displayWin)} Kz
              </span>
            </div>
          </div>
        </div>

        {/* Animated Mascot & Fortune Multiplier Row */}
        <div className="flex items-center justify-between px-3 pt-1.5 pb-0.5">
          {/* Animated Mascot */}
          <motion.div
            className="flex items-center gap-2"
            animate={
              gameState === "win" || gameState === "mega-win"
                ? { y: [0, -8, 0], scale: [1, 1.08, 1] }
                : spinning
                ? { rotate: [-2, 2, -2], scale: [1, 1.03, 1] }
                : { y: [0, -4, 0] }
            }
            transition={{
              duration: spinning ? 0.35 : gameState === "win" ? 0.6 : 2.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <img
              src={TIGER_MASCOT}
              alt="Fortune Tiger"
              className="w-14 h-14 object-contain drop-shadow-xl select-none"
            />
            <div className="flex flex-col">
              <span className="text-[10px] text-amber-400 font-semibold uppercase tracking-wider">
                Tigre da Fortuna
              </span>
              <span
                className="text-xs font-bold text-white tracking-wide"
                style={{ fontFamily: "'Russo One', sans-serif" }}
              >
                {spinning
                  ? "🔥 A Rodar..."
                  : gameState === "win" || gameState === "mega-win"
                  ? "🎉 GANHOU!"
                  : "🍀 Boa Sorte!"}
              </span>
            </div>
          </motion.div>

          {/* Golden Multiplier Pot x10 */}
          <motion.div
            className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-amber-400/50 shadow-md"
            style={{
              background: "linear-gradient(135deg, rgba(255,215,0,0.18), rgba(184,134,11,0.35))",
            }}
            animate={
              gameState === "mega-win"
                ? {
                    scale: [1, 1.12, 1],
                    boxShadow: [
                      "0 0 10px rgba(255,215,0,0.3)",
                      "0 0 25px rgba(255,215,0,0.8)",
                      "0 0 10px rgba(255,215,0,0.3)",
                    ],
                  }
                : { scale: [1, 1.03, 1] }
            }
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          >
            <span className="text-base select-none">🧧</span>
            <div className="flex flex-col items-center">
              <span className="text-[7px] uppercase font-bold text-amber-300 tracking-wider">Bónus</span>
              <span
                className="text-xs font-black text-amber-300"
                style={{ fontFamily: "'Orbitron', sans-serif" }}
              >
                x10
              </span>
            </div>
          </motion.div>
        </div>

        {/* Dynamic Game Announcement Banner */}
        <StatusBanner state={gameState} />

        {/* Slot Machine Machine Body */}
        <div className="mx-4 relative">
          {/* Glowing Golden Border Frame */}
          <div
            className="absolute -inset-[3px] rounded-xl z-0 transition-all duration-300"
            style={{
              background:
                gameState === "lose"
                  ? "linear-gradient(180deg, #ef4444 0%, #b91c1c 20%, #ef4444 40%, #ff6b6b 50%, #ef4444 60%, #b91c1c 80%, #ef4444 100%)"
                  : "linear-gradient(180deg, #DAA520 0%, #B8860B 20%, #DAA520 40%, #FFD700 50%, #DAA520 60%, #B8860B 80%, #DAA520 100%)",
              boxShadow:
                gameState === "lose"
                  ? "0 0 25px rgba(239,68,68,0.7), inset 0 0 10px rgba(239,68,68,0.3)"
                  : "0 0 20px rgba(218,165,32,0.5), inset 0 0 10px rgba(255,215,0,0.3)",
            }}
          />

          {/* Golden Column Pillars */}
          <div
            className="absolute -left-3 top-0 bottom-0 w-5 z-30 rounded-l pointer-events-none"
            style={{
              background: "linear-gradient(90deg, #6B4C14, #B8860B, #DAA520, #FFD700, #DAA520, #B8860B, #6B4C14)",
              boxShadow: "2px 0 8px rgba(0,0,0,0.3)",
            }}
          />
          <div
            className="absolute -right-3 top-0 bottom-0 w-5 z-30 rounded-r pointer-events-none"
            style={{
              background: "linear-gradient(90deg, #6B4C14, #B8860B, #DAA520, #FFD700, #DAA520, #B8860B, #6B4C14)",
              boxShadow: "-2px 0 8px rgba(0,0,0,0.3)",
            }}
          />

          {/* Payline badges on left: 1, 2, 3 */}
          <div className="absolute -left-7 top-0 bottom-0 flex flex-col justify-around z-40 py-1 pointer-events-none">
            {["1", "2", "3"].map((line) => (
              <div
                key={line}
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold select-none"
                style={{
                  background: "linear-gradient(135deg, #DAA520, #FFD700)",
                  color: "#4A0808",
                  boxShadow: "0 0 6px rgba(218,165,32,0.5)",
                }}
              >
                {line}
              </div>
            ))}
          </div>

          {/* Payline badges on right: 5, 2, 4 */}
          <div className="absolute -right-7 top-0 bottom-0 flex flex-col justify-around z-40 py-1 pointer-events-none">
            {["5", "2", "4"].map((line) => (
              <div
                key={line}
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold select-none"
                style={{
                  background: "linear-gradient(135deg, #DAA520, #FFD700)",
                  color: "#4A0808",
                  boxShadow: "0 0 6px rgba(218,165,32,0.5)",
                }}
              >
                {line}
              </div>
            ))}
          </div>

          {/* Reel Grid Container */}
          <motion.div
            className="relative z-10 rounded-xl overflow-hidden shadow-2xl border border-amber-500/35"
            style={{ background: "#180404" }}
            animate={gridShake ? { x: [-1.5, 1.5, -1, 1, 0] } : {}}
            transition={{ duration: 0.35, ease: "easeInOut" }}
          >
            <div className="flex w-full" style={{ height: "270px" }}>
              {grid.map((colSymbols, colIdx) => (
                <ReelColumn
                  key={colIdx}
                  symbols={colSymbols}
                  spinning={spinning}
                  delay={colIdx * 0.14}
                  winRow={winLine ? winLine[colIdx] : null}
                />
              ))}
            </div>

            {/* Win Amount Overlay Pop-up */}
            <AnimatePresence>
              {showWinOverlay && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center z-40 overflow-hidden"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <motion.div
                    className="absolute inset-0 bg-black/65"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  />

                  <motion.div
                    className="absolute rounded-full pointer-events-none"
                    style={{
                      width: 300,
                      height: 300,
                      background: winDetails.isMega
                        ? "radial-gradient(circle, rgba(255,69,0,0.35) 0%, rgba(255,215,0,0.15) 40%, transparent 70%)"
                        : "radial-gradient(circle, rgba(255,215,0,0.3) 0%, rgba(218,165,32,0.1) 40%, transparent 70%)",
                    }}
                    animate={{ scale: [0, 2.5, 2], opacity: [0, 1, 0.6] }}
                    transition={{ duration: 0.6 }}
                  />

                  {/* Coin Particles Burst */}
                  {[...Array(winDetails.isMega ? 16 : 8)].map((_, i) => {
                    const total = winDetails.isMega ? 16 : 8;
                    const angle = (i / total) * Math.PI * 2;
                    const dist = 80 + Math.random() * 60;
                    return (
                      <motion.div
                        key={`coin-${i}`}
                        className="absolute rounded-full pointer-events-none"
                        style={{
                          width: 5 + Math.random() * 4,
                          height: 5 + Math.random() * 4,
                          background:
                            i % 3 === 0 ? "#FFD700" : i % 3 === 1 ? "#FF8C00" : "#FFF8DC",
                          boxShadow: `0 0 8px ${i % 2 === 0 ? "#FFD700" : "#FF8C00"}`,
                        }}
                        initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                        animate={{
                          x: Math.cos(angle) * dist,
                          y: Math.sin(angle) * dist,
                          opacity: [0, 1, 0],
                          scale: [0, 2, 0],
                        }}
                        transition={{
                          duration: 1,
                          delay: 0.15 + i * 0.03,
                          ease: "easeOut",
                        }}
                      />
                    );
                  })}

                  <motion.div
                    className="text-center relative z-10 select-none"
                    initial={{ scale: 0.75, opacity: 0 }}
                    animate={{ scale: [0.75, 1.06, 1], opacity: 1 }}
                    transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <motion.p
                      className="text-sm mb-2 tracking-widest font-bold"
                      style={{
                        color: "#FFD700",
                        fontFamily: "'Russo One', sans-serif",
                      }}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      {winDetails.label}
                    </motion.p>
                    <motion.p
                      className="text-4xl font-bold"
                      style={{
                        background: winDetails.isMega
                          ? "linear-gradient(180deg, #FF4500, #FFD700, #FF4500)"
                          : "linear-gradient(180deg, #FFD700, #DAA520)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        fontFamily: "'Orbitron', sans-serif",
                        filter: `drop-shadow(0 0 ${winDetails.isMega ? 30 : 15}px rgba(255,215,0,0.9))`,
                      }}
                      animate={
                        winDetails.isMega
                          ? {
                              scale: [1, 1.08, 1],
                            }
                          : {}
                      }
                      transition={{ duration: 0.8, repeat: Infinity }}
                    >
                      +{formatKz(winDetails.amount)} Kz
                    </motion.p>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Bottom Play Controls */}
        <div className="flex items-center justify-center gap-3 mt-4 px-4">
          {/* Turbo Toggle Button */}
          <motion.button
            onClick={() => {
              setTurbo(!turbo);
              audio.playButtonClick();
            }}
            className="w-12 h-12 rounded-full flex flex-col items-center justify-center cursor-pointer transition-all"
            style={{
              background: turbo
                ? "linear-gradient(135deg, hsl(45, 100%, 55%), hsl(35, 100%, 45%))"
                : "linear-gradient(135deg, hsl(0, 60%, 20%), hsl(0, 60%, 12%))",
              border: `2px solid ${turbo ? "hsl(45, 100%, 60%)" : "hsla(45, 80%, 50%, 0.4)"}`,
              boxShadow: turbo ? "0 0 12px hsla(45, 100%, 50%, 0.5)" : "none",
            }}
            whileTap={{ scale: 0.9 }}
          >
            <span className="text-base">⚡</span>
            <span
              className="text-[7px] font-bold"
              style={{
                color: turbo ? "hsl(30, 10%, 8%)" : "hsl(45, 100%, 50%)",
              }}
            >
              TURBO
            </span>
          </motion.button>

          {/* Bet Decrement */}
          <motion.button
            onClick={() => audio.playButtonClick()}
            className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold cursor-pointer"
            style={{
              background: "linear-gradient(135deg, hsl(0, 60%, 20%), hsl(0, 60%, 12%))",
              border: "2px solid hsla(45, 80%, 50%, 0.4)",
              color: "hsl(45, 100%, 50%)",
            }}
            whileTap={{ scale: 0.9 }}
          >
            −
          </motion.button>

          {/* Central Main Spin Button */}
          <motion.button
            onClick={executeSpin}
            disabled={spinning || spinCount >= 10}
            className="w-[72px] h-[72px] rounded-full flex items-center justify-center text-base font-bold disabled:opacity-50 cursor-pointer select-none"
            style={{
              background: spinning
                ? "hsl(0, 0%, 30%)"
                : "linear-gradient(135deg, hsl(140, 70%, 45%), hsl(140, 60%, 35%))",
              border: "4px solid hsl(45, 100%, 50%)",
              color: spinning ? "hsl(0, 0%, 50%)" : "hsl(0, 0%, 100%)",
              fontFamily: "'Russo One', sans-serif",
              boxShadow: spinning
                ? "none"
                : "0 0 24px hsla(140, 70%, 45%, 0.5), inset 0 0 12px hsla(0, 0%, 100%, 0.1)",
            }}
            whileTap={spinning ? {} : { scale: 0.93 }}
          >
            {spinning ? "..." : spinCount >= 10 ? "FIM" : "JOGAR"}
          </motion.button>

          {/* Bet Increment */}
          <motion.button
            onClick={() => audio.playButtonClick()}
            className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold cursor-pointer"
            style={{
              background: "linear-gradient(135deg, hsl(0, 60%, 20%), hsl(0, 60%, 12%))",
              border: "2px solid hsla(45, 80%, 50%, 0.4)",
              color: "hsl(45, 100%, 50%)",
            }}
            whileTap={{ scale: 0.9 }}
          >
            +
          </motion.button>

          {/* Auto Spin Toggle Button */}
          <motion.button
            onClick={() => {
              setAutoSpin(!autoSpin);
              audio.playButtonClick();
            }}
            className="w-12 h-12 rounded-full flex flex-col items-center justify-center cursor-pointer transition-all"
            style={{
              background: autoSpin
                ? "linear-gradient(135deg, hsl(45, 100%, 55%), hsl(35, 100%, 45%))"
                : "linear-gradient(135deg, hsl(0, 60%, 20%), hsl(0, 60%, 12%))",
              border: `2px solid ${autoSpin ? "hsl(45, 100%, 60%)" : "hsla(45, 80%, 50%, 0.4)"}`,
              boxShadow: autoSpin ? "0 0 12px hsla(45, 100%, 50%, 0.5)" : "none",
            }}
            whileTap={{ scale: 0.9 }}
          >
            <span className="text-base">🏆</span>
            <span
              className="text-[7px] font-bold"
              style={{
                color: autoSpin ? "hsl(30, 10%, 8%)" : "hsl(45, 100%, 50%)",
              }}
            >
              AUTO
            </span>
          </motion.button>
        </div>

        {/* Bottom Withdraw Prompt Button */}
        <div className="px-4 mt-3 mb-6">
          <motion.button
            onClick={() => {
              if (spinCount >= 10) {
                setPageMode("bonus-end");
              }
            }}
            className="w-full py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 cursor-pointer transition-opacity"
            style={{
              background: "linear-gradient(135deg, hsl(45, 100%, 55%), hsl(35, 100%, 42%))",
              color: "hsl(30, 10%, 8%)",
              fontFamily: "'Russo One', sans-serif",
              boxShadow: "0 4px 16px hsla(45, 100%, 50%, 0.3)",
              opacity: spinCount >= 10 ? 1 : 0.5,
              cursor: spinCount >= 10 ? "pointer" : "not-allowed",
            }}
            whileTap={spinCount >= 10 ? { scale: 0.97 } : {}}
          >
            🔒 LEVANTAR
          </motion.button>
        </div>
      </div>
    </div>
  );
};
