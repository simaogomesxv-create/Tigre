import { LiveStreamView } from "../components/LiveStreamView";

export const VslPage = () => {
  return <LiveStreamView totalWin={130000} />;
};
