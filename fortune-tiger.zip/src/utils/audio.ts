function triggerVibrate(pattern: number | number[]) {
  try {
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  } catch {
    // Ignore devices that block vibration
  }
}

class SoundSystem {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private isAmbientMuted: boolean = false;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private ambientTimer: number | null = null;
  private isAmbientPlaying: boolean = false;
  private ambientNodes: { stop: () => void }[] = [];

  constructor() {
    if (typeof window !== "undefined") {
      const savedMute = localStorage.getItem("ft_sound_muted");
      if (savedMute !== null) {
        this.isMuted = savedMute === "true";
      }
      const savedAmbientMute = localStorage.getItem("ft_ambient_muted");
      if (savedAmbientMute !== null) {
        this.isAmbientMuted = savedAmbientMute === "true";
      }
    }
  }

  private initContext(): AudioContext | null {
    try {
      if (!this.ctx || this.ctx.state === "closed") {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AudioCtx();

        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.85, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.setValueAtTime(0.75, this.ctx.currentTime);
        this.sfxGain.connect(this.masterGain);

        this.ambientGain = this.ctx.createGain();
        this.ambientGain.gain.setValueAtTime(this.isAmbientMuted ? 0 : 0.28, this.ctx.currentTime);
        this.ambientGain.connect(this.masterGain);
      }

      if (this.ctx.state === "suspended") {
        this.ctx.resume();
      }

      return this.ctx;
    } catch {
      return null;
    }
  }

  public getContext(): AudioContext | null {
    return this.initContext();
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (typeof window !== "undefined") {
      localStorage.setItem("ft_sound_muted", String(this.isMuted));
    }
    if (this.ctx && this.masterGain) {
      const t = this.ctx.currentTime;
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, t);
      this.masterGain.gain.linearRampToValueAtTime(this.isMuted ? 0 : 0.85, t + 0.08);
    }
    return this.isMuted;
  }

  public toggleAmbientMute(): boolean {
    this.isAmbientMuted = !this.isAmbientMuted;
    if (typeof window !== "undefined") {
      localStorage.setItem("ft_ambient_muted", String(this.isAmbientMuted));
    }
    if (this.ctx && this.ambientGain) {
      const t = this.ctx.currentTime;
      this.ambientGain.gain.setValueAtTime(this.ambientGain.gain.value, t);
      this.ambientGain.gain.linearRampToValueAtTime(this.isAmbientMuted ? 0 : 0.28, t + 0.15);
    }
    return this.isAmbientMuted;
  }

  public getMuteState() {
    return {
      isMuted: this.isMuted,
      isAmbientMuted: this.isAmbientMuted,
    };
  }

  private createReverb(audioCtx: AudioContext, duration = 1.8, decay = 2.2) {
    const sampleRate = audioCtx.sampleRate;
    const length = sampleRate * duration;
    const impulse = audioCtx.createBuffer(2, length, sampleRate);
    for (let c = 0; c < 2; c++) {
      const channelData = impulse.getChannelData(c);
      for (let i = 0; i < length; i++) {
        channelData[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    const convolver = audioCtx.createConvolver();
    convolver.buffer = impulse;
    return convolver;
  }

  private playTone(
    audioCtx: AudioContext,
    destination: AudioNode,
    freq: number,
    startTime: number,
    duration: number,
    volume: number,
    type: OscillatorType = "sine",
    cutoff = 4000
  ) {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);

    filter.type = "lowpass";
    filter.frequency.setValueAtTime(cutoff, startTime);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(destination);

    // Smooth sinusoidal/exponential envelope without clicks
    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(volume, startTime + Math.min(0.02, duration * 0.15));
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.05);
  }

  private playNoise(
    audioCtx: AudioContext,
    destination: AudioNode,
    startTime: number,
    duration: number,
    volume: number,
    filterFreq = 3000
  ) {
    const bufferSize = Math.floor(audioCtx.sampleRate * duration);
    if (bufferSize <= 0) return;
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;

    const filter = audioCtx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(filterFreq, startTime);

    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(volume, startTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(destination);

    source.start(startTime);
    source.stop(startTime + duration + 0.02);
  }

  // --- BUTTON CLICKS (Soft & Tactile) ---
  public playButtonClick() {
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    // Soft organic click (warm sine + gentle lowpassed transient)
    this.playTone(audioCtx, sfx, 780, t, 0.045, 0.08, "sine", 2000);
    this.playTone(audioCtx, sfx, 520, t + 0.008, 0.05, 0.06, "sine", 1500);
  }

  // --- SPIN CLICK (Smooth startup whoosh) ---
  public playSpinClick() {
    triggerVibrate(20);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    // Smooth rounded mechanical whir
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();

    osc.type = "sine";
    osc.frequency.setValueAtTime(280, t);
    osc.frequency.exponentialRampToValueAtTime(90, t + 0.25);

    filter.type = "lowpass";
    filter.frequency.setValueAtTime(800, t);

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.12, t + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(sfx);

    osc.start(t);
    osc.stop(t + 0.3);

    // Soft airy whoosh
    this.playNoise(audioCtx, sfx, t, 0.12, 0.05, 2200);
  }

  // --- REEL STOP (Warm Velvet Thud) ---
  public playReelStop(offset = 0) {
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime + offset;

    // Warm rounded thud (gentle dual sine + soft resonance)
    this.playTone(audioCtx, sfx, 150, t, 0.09, 0.15, "sine", 600);
    this.playTone(audioCtx, sfx, 95, t, 0.12, 0.12, "sine", 400);
    this.playNoise(audioCtx, sfx, t, 0.03, 0.04, 1800);
  }

  // --- WIN CELEBRATIONS (Silky, Rich & Harmonious) ---
  public playWinSound() {
    triggerVibrate([40, 30, 60]);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    const reverb = this.createReverb(audioCtx, 1.6, 2.2);
    const dry = audioCtx.createGain();
    const wet = audioCtx.createGain();
    dry.gain.setValueAtTime(0.45, t);
    wet.gain.setValueAtTime(0.35, t);

    dry.connect(sfx);
    reverb.connect(wet);
    wet.connect(sfx);

    // Warm Asian pentatonic celebration: C5, E5, G5, C6 (523, 659, 784, 1047 Hz)
    [523, 659, 784, 1047].forEach((freq, idx) => {
      const time = t + idx * 0.09;
      this.playTone(audioCtx, dry, freq, time, 0.45, 0.12, "sine", 2800);
      this.playTone(audioCtx, reverb, freq, time, 0.6, 0.09, "sine", 3200);
    });

    // Soft high chime sparkle
    [1568, 2093].forEach((freq, idx) => {
      this.playTone(audioCtx, reverb, freq, t + 0.3 + idx * 0.08, 0.4, 0.04, "sine", 3500);
    });

    // Gentle warm base bell
    this.playTone(audioCtx, dry, 261.63, t, 0.7, 0.09, "sine", 800);
  }

  public playMegaWinSound() {
    triggerVibrate([60, 40, 80, 40, 120]);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    const reverb = this.createReverb(audioCtx, 2.5, 2.0);
    const dry = audioCtx.createGain();
    const wet = audioCtx.createGain();
    dry.gain.setValueAtTime(0.5, t);
    wet.gain.setValueAtTime(0.4, t);

    dry.connect(sfx);
    reverb.connect(wet);
    wet.connect(sfx);

    // Lush warm fanfare arpeggios
    const fanfareNotes = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98];
    fanfareNotes.forEach((freq, idx) => {
      const noteTime = t + idx * 0.1;
      this.playTone(audioCtx, dry, freq, noteTime, 0.5, 0.12, "sine", 3000);
      this.playTone(audioCtx, reverb, freq, noteTime, 0.8, 0.08, "triangle", 3200);
    });

    // Sustained celebratory harmony (soft chords)
    const sustainTime = t + 0.75;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq) => {
      this.playTone(audioCtx, reverb, freq, sustainTime, 1.6, 0.07, "sine", 2500);
      this.playTone(audioCtx, dry, freq, sustainTime, 1.2, 0.05, "triangle", 2200);
    });

    // Soft warm sub rumble
    this.playTone(audioCtx, dry, 75, t, 0.9, 0.12, "sine", 300);

    // Soft golden chime cascades
    for (let i = 0; i < 10; i++) {
      const chimeTime = t + 0.4 + i * 0.09;
      this.playTone(audioCtx, reverb, 1800 + (i % 5) * 220, chimeTime, 0.35, 0.025, "sine", 3500);
    }
  }

  // --- COIN COUNT (Soft Metallic Pings) ---
  public playCoinCount() {
    triggerVibrate([15, 15, 15]);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    const reverb = this.createReverb(audioCtx, 0.6, 2.5);
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.2, t);
    reverb.connect(gain);
    gain.connect(sfx);

    for (let i = 0; i < 6; i++) {
      const time = t + i * 0.06;
      const freq = 2400 + (i % 3) * 350;
      this.playTone(audioCtx, sfx, freq, time, 0.05, 0.035, "sine", 4000);
      this.playTone(audioCtx, reverb, freq * 1.5, time, 0.08, 0.02, "sine", 4500);
    }
  }

  // --- LOSE SOUND (Gentle Mellow Descend) ---
  public playLoseSound() {
    triggerVibrate(15);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    // Gentle mellow descending sines (no harsh buzzy saws)
    this.playTone(audioCtx, sfx, 290, t, 0.22, 0.08, "sine", 1200);
    this.playTone(audioCtx, sfx, 240, t + 0.12, 0.25, 0.07, "sine", 1000);
    this.playTone(audioCtx, sfx, 190, t + 0.25, 0.32, 0.06, "sine", 800);
  }

  public playBonusEnd() {
    triggerVibrate([40, 30, 80]);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    const reverb = this.createReverb(audioCtx, 2.0, 2.0);
    const dry = audioCtx.createGain();
    const wet = audioCtx.createGain();
    dry.gain.setValueAtTime(0.45, t);
    wet.gain.setValueAtTime(0.35, t);

    dry.connect(sfx);
    reverb.connect(wet);
    wet.connect(sfx);

    const notes = [659.25, 783.99, 880.0, 1046.5, 1318.5, 1567.98];
    notes.forEach((freq, idx) => {
      const time = t + idx * 0.1;
      this.playTone(audioCtx, dry, freq, time, 0.35, 0.09, "sine", 3000);
      this.playTone(audioCtx, reverb, freq, time, 0.5, 0.06, "sine", 3200);
    });

    const sustained = t + 0.8;
    [1046.5, 1318.5, 1567.98].forEach((freq) => {
      this.playTone(audioCtx, reverb, freq, sustained, 1.4, 0.05, "sine", 2500);
    });
  }

  public playSuccess() {
    triggerVibrate([30, 20, 40]);
    const audioCtx = this.getContext();
    const sfx = this.sfxGain;
    if (!audioCtx || !sfx) return;
    const t = audioCtx.currentTime;

    const reverb = this.createReverb(audioCtx, 1.2, 2.2);
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.2, t);
    reverb.connect(gain);
    gain.connect(sfx);

    [659.25, 880.0, 1318.5].forEach((freq, idx) => {
      const time = t + idx * 0.12;
      this.playTone(audioCtx, sfx, freq, time, 0.3, 0.08, "sine", 3000);
      this.playTone(audioCtx, reverb, freq, time, 0.45, 0.05, "sine", 3200);
    });
  }

  // --- AMBIENT JUNGLE AUDIO SYSTEM (Smooth, Relaxing, Natural) ---
  public startAmbientJungle() {
    if (this.isAmbientPlaying) return;
    const audioCtx = this.getContext();
    const ambient = this.ambientGain;
    if (!audioCtx || !ambient) return;

    this.isAmbientPlaying = true;
    this.ambientNodes = [];

    try {
      const t = audioCtx.currentTime;
      const reverb = this.createReverb(audioCtx, 3.0, 2.2);
      const reverbGain = audioCtx.createGain();
      reverbGain.gain.setValueAtTime(0.25, t);
      reverb.connect(reverbGain);
      reverbGain.connect(ambient);

      // 1. Forest Canopy Breeze (soft soothing low-passed pink noise)
      const bufferLength = audioCtx.sampleRate * 4;
      const noiseBuffer = audioCtx.createBuffer(2, bufferLength, audioCtx.sampleRate);
      for (let ch = 0; ch < 2; ch++) {
        const data = noiseBuffer.getChannelData(ch);
        let b0 = 0, b1 = 0, b2 = 0;
        for (let i = 0; i < bufferLength; i++) {
          const white = Math.random() * 2 - 1;
          b0 = 0.99765 * b0 + white * 0.099046;
          b1 = 0.96300 * b1 + white * 0.296516;
          b2 = 0.57000 * b2 + white * 1.0526913;
          data[i] = (b0 + b1 + b2 + white * 0.1848) * 0.025;
        }
      }

      const noiseSource = audioCtx.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      noiseSource.loop = true;

      const windFilter = audioCtx.createBiquadFilter();
      windFilter.type = "lowpass";
      windFilter.frequency.setValueAtTime(260, t);

      // Slow gentle LFO for breeze swelling
      const lfo = audioCtx.createOscillator();
      const lfoGain = audioCtx.createGain();
      lfo.frequency.setValueAtTime(0.08, t);
      lfoGain.gain.setValueAtTime(90, t);
      lfo.connect(lfoGain);
      lfoGain.connect(windFilter.frequency);

      const windGain = audioCtx.createGain();
      windGain.gain.setValueAtTime(0.12, t);

      noiseSource.connect(windFilter);
      windFilter.connect(windGain);
      windGain.connect(ambient);
      windGain.connect(reverb);

      noiseSource.start(t);
      lfo.start(t);

      this.ambientNodes.push({
        stop: () => {
          try {
            noiseSource.stop();
            lfo.stop();
          } catch {}
        },
      });

      // 2. Warm Sacred Temple Sub Drone (65Hz sine)
      const droneOsc = audioCtx.createOscillator();
      droneOsc.type = "sine";
      droneOsc.frequency.setValueAtTime(65.41, t);

      const droneGain = audioCtx.createGain();
      droneGain.gain.setValueAtTime(0.025, t);

      const droneFilter = audioCtx.createBiquadFilter();
      droneFilter.type = "lowpass";
      droneFilter.frequency.setValueAtTime(95, t);

      droneOsc.connect(droneFilter);
      droneFilter.connect(droneGain);
      droneGain.connect(ambient);

      droneOsc.start(t);

      this.ambientNodes.push({
        stop: () => {
          try {
            droneOsc.stop();
          } catch {}
        },
      });

      // 3. Gentle Wind Chimes & Bamboo Flute accents
      const pentatonicNotes = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5];

      const triggerAmbientChime = () => {
        const amb = this.ambientGain;
        if (!this.isAmbientPlaying || !this.ctx || !amb) return;
        const curT = this.ctx.currentTime;
        const note = pentatonicNotes[Math.floor(Math.random() * pentatonicNotes.length)];
        const chimeVol = 0.02 + Math.random() * 0.015;

        // Soft bell chime with gentle decay
        this.playTone(this.ctx, reverb, note, curT, 3.2, chimeVol, "sine", 2500);

        // Soft cricket chirp cluster occasionally
        if (Math.random() > 0.5) {
          const chirpT = curT + 0.6 + Math.random();
          for (let k = 0; k < 2; k++) {
            this.playTone(this.ctx, amb, 4200 + Math.random() * 400, chirpT + k * 0.09, 0.02, 0.008, "sine", 5000);
          }
        }
      };

      const chimeInterval = () => {
        if (!this.isAmbientPlaying) return;
        triggerAmbientChime();
        const nextDelay = 4000 + Math.random() * 4500;
        this.ambientTimer = window.setTimeout(chimeInterval, nextDelay);
      };

      this.ambientTimer = window.setTimeout(chimeInterval, 2000);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  public stopAmbientJungle() {
    this.isAmbientPlaying = false;
    if (this.ambientTimer !== null) {
      window.clearTimeout(this.ambientTimer);
      this.ambientTimer = null;
    }
    this.ambientNodes.forEach((node) => node.stop());
    this.ambientNodes = [];
  }
}

// Global singleton audio instance
export const audioManager = new SoundSystem();

// Factory adapter for compatibility
export function createAudioEngine() {
  return audioManager;
}
