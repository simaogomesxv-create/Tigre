import { CommentItem, SpinOutcome, SymbolType } from "../types/game";

export const TEMPLE_BG = "/assets/temple-bg-BAZnpfeV.jpg";
export const TIGER_MASCOT = "/assets/tiger-mascot-Dq_NVJZy.png";
export const EXPRESS_LOGO = "/assets/express-logo-BjH-4Re2.png";
export const MULTICAIXA_LOGO = "/assets/multicaixa-logo-Ef9odcx-.webp";

export const SYMBOLS: SymbolType[] = ["🐯", "🪙", "💎", "🎰", "🔔", "🍀", "7️⃣", "🎲"];

export const SPIN_SEQUENCE: SpinOutcome[] = [
  { win: true, label: "GANHO", amount: 5000 },
  { win: false, label: "", amount: 0 },
  { win: true, label: "MEGA GANHO", amount: 15000 },
  { win: true, label: "GANHO", amount: 8000 },
  { win: false, label: "", amount: 0 },
  { win: true, label: "GANHO", amount: 10000 },
  { win: false, label: "", amount: 0 },
  { win: true, label: "SUPER MEGA GANHO", amount: 50000 },
  { win: true, label: "GANHO", amount: 7000 },
  { win: true, label: "MEGA GANHO", amount: 12000 },
];

export const AVATARS = {
  virginia: "/assets/avatars/virginia.webp",
  p20: "/assets/avatars/20.jpeg",
  p21: "/assets/avatars/21.jpeg",
  p22: "/assets/avatars/22.jpeg",
  p23: "/assets/avatars/23.jpeg",
  p24: "/assets/avatars/24.jpeg",
  p25: "/assets/avatars/25.jpeg",
  p26: "/assets/avatars/26.jpeg",
  miami: "/assets/avatars/miami.jpeg",
  work: "/assets/avatars/work.jpeg",
};

export const INITIAL_COMMENTS: CommentItem[] = [
  { name: "Luísa Capitango", time: "há 14 min", text: "Boa noite gente! Cheguei agora 🙋‍♀️", color: "#8b5cf6", photo: AVATARS.p20 },
  { name: "Manuel Fernando", time: "há 13 min", text: "Virgínia, eu já tinha tentado outras coisas e nada funcionou. Vamos ver dessa vez 🙏", color: "#0ea5e9", photo: AVATARS.p22 },
  { name: "Virgínia Fonseca", time: "há 12 min", text: "Bem-vindos meus amores ❤️ Fiquem até ao fim que vou mostrar tudo passo a passo!", color: "#f97316", author: true, photo: AVATARS.virginia },
  { name: "Ana Paula", time: "há 11 min", text: "Estou a assistir desde Luanda 🇦🇴", color: "#ec4899", photo: AVATARS.p21 },
  { name: "Edson Miguel", time: "há 10 min", text: "Já recebi 45.000 Kz na conta Multicaixa 🤠🤠", color: "#10b981", photo: AVATARS.p25 },
  { name: "Helena Sebastião", time: "há 9 min", text: "Sério??? Como fizeste?", color: "#f59e0b", photo: AVATARS.p20 },
  { name: "Carlos Mateus", time: "há 8 min", text: "Funciona mesmo gente, eu também já recebi 👏", color: "#6366f1", photo: AVATARS.p23 },
  { name: "Virgínia Fonseca", time: "há 7 min", text: "@Helena segue exactamente o que eu mostro no vídeo, sem pular nenhum passo 😊", color: "#f97316", author: true, photo: AVATARS.virginia },
  { name: "Beatriz Sousa", time: "há 6 min", text: "Acabei de entrar, alguém pode resumir? 🙈", color: "#a855f7", photo: AVATARS.p21 },
  { name: "Nelson Cabral", time: "há 5 min", text: "Recebi 30.000 Kz agora mesmo!! Muito obrigado Virgínia 🙌", color: "#14b8a6", photo: AVATARS.p26 },
  { name: "Sofia Rodrigues", time: "há 4 min", text: "Estou a fazer o passo a passo, funciona sim! ✨", color: "#e11d48", photo: AVATARS.p20 },
  { name: "Pedro Almeida", time: "há 3 min", text: "Melhor coisa que fiz este mês 💰", color: "#0284c7", photo: AVATARS.miami },
  { name: "Joana Silva", time: "há 2 min", text: "Alguém sabe se dá para IBAN também? 🤔", color: "#7c3aed", photo: AVATARS.p21 },
  { name: "Virgínia Fonseca", time: "há 1 min", text: "Sim @Joana! Multicaixa Express ou IBAN, escolhes no fim 💖", color: "#f97316", author: true, photo: AVATARS.virginia },
  { name: "Tiago Bernardo", time: "agora", text: "Obrigado Virgínia, tamo junto! 🔥", color: "#f43f5e", photo: AVATARS.work },
  { name: "Rui Domingos", time: "agora", text: "Confirmado aqui também ✅", color: "#22c55e", photo: AVATARS.p24 },
];

export function formatKz(amount: number): string {
  return new Intl.NumberFormat("pt-AO").format(amount);
}

export function createRandomGrid(): SymbolType[][] {
  return Array.from({ length: 3 }, () =>
    Array.from({ length: 3 }, () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)])
  );
}

export function generateWinningGrid(): { grid: SymbolType[][]; winLine: [number, number, number] } {
  const row = Math.floor(Math.random() * 3);
  const winningSym = SYMBOLS[Math.floor(Math.random() * 4)];
  const grid = Array.from({ length: 3 }, () =>
    Array.from({ length: 3 }, () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)])
  );
  for (let c = 0; c < 3; c++) {
    grid[c][row] = winningSym;
  }
  return { grid, winLine: [row, row, row] };
}

export function generateLosingGrid(): SymbolType[][] {
  const grid = createRandomGrid();
  for (let r = 0; r < 3; r++) {
    if (grid[0][r] === grid[1][r] && grid[1][r] === grid[2][r]) {
      const remaining = SYMBOLS.filter((s) => s !== grid[0][r]);
      grid[2][r] = remaining[Math.floor(Math.random() * remaining.length)];
    }
  }
  return grid;
}
