import { BrowserRouter, Route, Routes } from "react-router-dom";
import { GamePage } from "./pages/GamePage";
import { NotFoundPage } from "./pages/NotFoundPage";
import { VslPage } from "./pages/VslPage";
import { WelcomePage } from "./pages/WelcomePage";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<WelcomePage />} />
        <Route path="/game" element={<GamePage />} />
        <Route path="/vsl" element={<VslPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}
